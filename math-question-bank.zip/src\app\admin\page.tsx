import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function AdminDashboard() {
  const [chapterCount, sectionCount, kpCount, questionCount] = await Promise.all([
    prisma.chapter.count(),
    prisma.section.count(),
    prisma.knowledgePoint.count(),
    prisma.question.count(),
  ]);

  const questionsByType = await prisma.question.groupBy({
    by: ["type"],
    _count: true,
  });

  const questionsByChapter = await prisma.chapter.findMany({
    include: { _count: { select: { questions: true } } },
    orderBy: { order: "asc" },
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">总览</h1>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl">{chapterCount}</CardTitle>
            <p className="text-sm text-muted-foreground">册数</p>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl">{sectionCount}</CardTitle>
            <p className="text-sm text-muted-foreground">章节</p>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl">{kpCount}</CardTitle>
            <p className="text-sm text-muted-foreground">知识点</p>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-3xl">{questionCount}</CardTitle>
            <p className="text-sm text-muted-foreground">题目</p>
          </CardHeader>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>题目类型分布</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {questionsByType.map((item) => (
                <div key={item.type} className="flex justify-between text-sm">
                  <span>
                    {item.type === "choice"
                      ? "选择题"
                      : item.type === "fill"
                        ? "填空题"
                        : "解答题"}
                  </span>
                  <span className="font-medium">{item._count}</span>
                </div>
              ))}
              {questionsByType.length === 0 && (
                <p className="text-sm text-muted-foreground">暂无题目</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>各册题目数量</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {questionsByChapter.map((ch) => (
                <div key={ch.id} className="flex justify-between text-sm">
                  <span>{ch.name}</span>
                  <span className="font-medium">{ch._count.questions}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}