import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/questions/variants?questionId=1&direction=harder|easier|any
// 查找同类变式题：与给定题目共享知识点，但难度不同
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const questionId = parseInt(searchParams.get("questionId") || "0");
  const direction = searchParams.get("direction") || "any";

  if (!questionId) {
    return NextResponse.json({ error: "缺少 questionId" }, { status: 400 });
  }

  // 获取原题的知识点
  const question = await prisma.question.findUnique({
    where: { id: questionId },
    include: {
      knowledgePoints: { select: { knowledgePointId: true } },
    },
  });

  if (!question) {
    return NextResponse.json({ error: "题目不存在" }, { status: 404 });
  }

  const kpIds = question.knowledgePoints.map((kp) => kp.knowledgePointId);
  if (kpIds.length === 0) {
    return NextResponse.json([]);
  }

  // 构建难度条件
  const difficultyFilter: Record<string, unknown> = {};
  if (direction === "harder") {
    difficultyFilter.gt = question.difficulty;
  } else if (direction === "easier") {
    difficultyFilter.lt = question.difficulty;
  }

  const where: Record<string, unknown> = {
    id: { not: questionId },
    knowledgePoints: {
      some: { knowledgePointId: { in: kpIds } },
    },
  };

  if (Object.keys(difficultyFilter).length > 0) {
    where.difficulty = difficultyFilter;
  }

  // 查找同类题，按共享知识点数量排序
  const variants = await prisma.question.findMany({
    where,
    take: 6,
    include: {
      chapter: true,
      knowledgePoints: { include: { knowledgePoint: true } },
    },
  });

  // 计算每道题与原题的共享知识点数，排序
  const scored = variants.map((v) => ({
    ...v,
    sharedKpCount: v.knowledgePoints.filter((kp) =>
      kpIds.includes(kp.knowledgePointId)
    ).length,
  }));

  scored.sort((a, b) => b.sharedKpCount - a.sharedKpCount);

  return NextResponse.json(scored.slice(0, 5));
}