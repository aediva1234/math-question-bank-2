import Link from "next/link";
import { Button } from "@/components/ui/button";
import { cookies } from "next/headers";
import { USER_COOKIE, ADMIN_COOKIE, verifyAdminToken, verifyUserToken } from "@/lib/auth";
import { BookOpen, FileText, Search, Upload, Shield } from "lucide-react";

export default async function Home() {
  const cookieStore = await cookies();
  const userToken = cookieStore.get(USER_COOKIE)?.value;
  const adminToken = cookieStore.get(ADMIN_COOKIE)?.value;

  let isLoggedIn = false;
  let userName = "";
  let isAdmin = false;

  if (userToken) {
    const user = await verifyUserToken(userToken);
    if (user) { isLoggedIn = true; userName = user.name; }
  }
  if (!isLoggedIn && adminToken) {
    if (verifyAdminToken(adminToken)) { isLoggedIn = true; userName = "管理员"; isAdmin = true; }
  }
  if (adminToken && verifyAdminToken(adminToken)) { isAdmin = true; }

  return (
    <div className="flex min-h-screen flex-col">
      {/* Navbar */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-20">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <Link href="/" className="flex items-center gap-2 font-bold text-lg text-primary">
            <BookOpen className="size-5" />
            高中数学题库
          </Link>
          <nav className="flex items-center gap-2">
            {isLoggedIn ? (
              <>
                <Link href="/questions" className="text-sm px-3 py-1.5 rounded-md hover:bg-muted transition-colors">
                  题库
                </Link>
                <Link href="/submit" className="text-sm px-3 py-1.5 rounded-md hover:bg-muted transition-colors flex items-center gap-1">
                  <Upload className="size-3.5" /> 投稿
                </Link>
                {isAdmin && (
                  <Link href="/admin" className="text-sm px-3 py-1.5 rounded-md hover:bg-muted transition-colors flex items-center gap-1">
                    <Shield className="size-3.5" /> 管理
                  </Link>
                )}
                <span className="text-sm text-muted-foreground ml-2 pl-2 border-l">{userName}</span>
              </>
            ) : (
              <>
                <Link href="/login"><Button variant="ghost" size="sm">登录</Button></Link>
                <Link href="/register"><Button size="sm">免费注册</Button></Link>
              </>
            )}
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="search-hero text-white">
        <div className="container mx-auto px-4 py-16 md:py-24 text-center">
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-4">
            高中数学 · 智能题库
          </h1>
          <p className="text-base md:text-lg text-white/80 max-w-xl mx-auto mb-8">
            覆盖人教A版必修+选择性必修全部章节，支持 LaTeX 公式、图片嵌入，
            {isLoggedIn ? "随时搜索和练习" : "注册即可免费使用"}
          </p>
          <div className="flex items-center justify-center gap-3">
            {isLoggedIn ? (
              <>
                <Link href="/questions">
                  <Button size="lg" variant="secondary">
                    <Search className="size-4 mr-2" /> 进入题库
                  </Button>
                </Link>
                <Link href="/submit">
                  <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                    <Upload className="size-4 mr-2" /> 投稿题目
                  </Button>
                </Link>
              </>
            ) : (
              <>
                <Link href="/register">
                  <Button size="lg" variant="secondary">免费注册</Button>
                </Link>
                <Link href="/login">
                  <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">登录</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="container mx-auto px-4 -mt-8 relative z-10">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: <BookOpen className="size-5" />, num: "5", label: "册数", sub: "必修 + 选择性必修" },
            { icon: <FileText className="size-5" />, num: "22", label: "章节", sub: "系统化知识结构" },
            { icon: <Search className="size-5" />, num: "98", label: "知识点", sub: "精细分类检索" },
            { icon: <Upload className="size-5" />, num: "投稿", label: "开放投稿", sub: "审核后入库共享" },
          ].map((item, i) => (
            <div key={i} className="stat-card bg-white rounded-lg border p-5 shadow-sm">
              <div className="flex items-center gap-2 text-primary mb-2">{item.icon}<span className="text-2xl font-bold">{item.num}</span></div>
              <p className="text-sm font-medium">{item.label}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{item.sub}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold text-center mb-10">核心功能</h2>
        <div className="grid gap-8 md:grid-cols-3">
          <div className="text-center space-y-3">
            <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto">
              <Search className="size-6 text-primary" />
            </div>
            <h3 className="font-semibold">多维度搜索</h3>
            <p className="text-sm text-muted-foreground">按册别、章节、知识点、题型、难度精准筛选题目</p>
          </div>
          <div className="text-center space-y-3">
            <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto">
              <Upload className="size-6 text-primary" />
            </div>
            <h3 className="font-semibold">LaTeX 投稿</h3>
            <p className="text-sm text-muted-foreground">支持完整 LaTeX 数学公式编辑，实时预览，图片嵌入</p>
          </div>
          <div className="text-center space-y-3">
            <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto">
              <Shield className="size-6 text-primary" />
            </div>
            <h3 className="font-semibold">审核机制</h3>
            <p className="text-sm text-muted-foreground">用户投稿经管理员审核后入库，保证题库质量</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 mt-auto">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          高中数学题库 · 教师个人工具 · 仅供教学使用
        </div>
      </footer>
    </div>
  );
}