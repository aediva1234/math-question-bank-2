"use client";

import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

export function DeleteButton({
  questionId,
  onDeleted,
}: {
  questionId: number;
  onDeleted?: () => void;
}) {
  const router = useRouter();

  async function handleDelete() {
    if (!confirm("确定删除这道题目？")) return;
    await fetch('/api/admin/questions?id=' + questionId, { method: "DELETE" });
    if (onDeleted) {
      onDeleted();
    } else {
      router.refresh();
    }
  }

  return (
    <Button
      size="sm"
      variant="ghost"
      className="h-7 text-xs text-destructive"
      onClick={handleDelete}
    >
      <Trash2 className="size-3.5" />
    </Button>
  );
}