"use client";

import { useState, useEffect, useCallback, use } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MathToolbar } from "@/components/admin/math-toolbar";
import { LivePreview } from "@/components/question/live-preview";
import { ImageUploadButton } from "@/components/admin/image-upload";
import { Plus, Trash2, Loader2, Save, ArrowLeft } from "lucide-react";
import Link from "next/link";

const TYPE_OPTIONS = [
  { value: "choice", label: "选择题" },
  { value: "fill", label: "填空题" },
  { value: "short_answer", label: "解答题" },
  { value: "proof", label: "证明题" },
];

export default function EditQuestionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const questionId = parseInt(id);

  const [loading, setLoading] = useState(true);
  const [type, setType] = useState("choice");
  const [difficulty, setDifficulty] = useState(3);
  const [year, setYear] = useState("");
  const [source, setSource] = useState("");
  const [stemLatex, setStemLatex] = useState("");
  const [options, setOptions] = useState([
    { label: "A", latex: "" }, { label: "B", latex: "" },
    { label: "C", latex: "" }, { label: "D", latex: "" },
  ]);
  const [answer, setAnswer] = useState("");
  const [solution, setSolution] = useState("");
  const [chapterId, setChapterId] = useState("");
  const [selectedKpIds, setSelectedKpIds] = useState<number[]>([]);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [chapters, setChapters] = useState<any[]>([]);
  const [status, setStatus] = useState("approved");

  const stemRef = { current: null as HTMLTextAreaElement | null };
  const solutionRef = { current: null as HTMLTextAreaElement | null };
  const activeRef = { current: null as HTMLTextAreaElement | null };

  // 加载章节列表
  useEffect(() => {
    fetch("/api/admin/chapters").then((r) => r.json()).then(setChapters).catch(() => {});
  }, []);

  // 加载题目数据
  useEffect(() => {
    async function load() {
      const res = await fetch("/api/admin/questions?id=" + questionId);
      const data = await res.json();
      const q = Array.isArray(data) ? data[0] : data;
      if (!q) { setError("题目不存在"); setLoading(false); return; }

      setType(q.type);
      setDifficulty(q.difficulty);
      setYear(q.year ? String(q.year) : "");
      setSource(q.source || "");
      setStemLatex(q.stemLatex || "");
      setAnswer(q.answer || "");
      setSolution(q.solution || "");
      setChapterId(q.chapterId ? String(q.chapterId) : "");
      setStatus(q.status || "approved");

      if (q.options) {
        try {
          const opts = JSON.parse(q.options);
          if (Array.isArray(opts) && opts.length > 0) setOptions(opts);
        } catch { /* keep defaults */ }
      }

      if (q.knowledgePoints) {
        setSelectedKpIds(q.knowledgePoints.map((kp: any) => kp.knowledgePointId || kp.knowledgePoint?.id).filter(Boolean));
      }

      if (q.images) {
        try { setUploadedImages(JSON.parse(q.images)); } catch { /* ignore */ }
      }

      setLoading(false);
    }
    load();
  }, [questionId]);

  const availableKps = chapterId
    ? chapters.find((c: any) => c.id === parseInt(chapterId))?.sections?.flatMap((s: any) => s.knowledgePoints) || []
    : [];

  const toggleKp = (kpId: number) => {
    setSelectedKpIds((prev) => (prev.includes(kpId) ? prev.filter((id) => id !== kpId) : [...prev, kpId]));
  };

  const updateOption = (index: number, latex: string) => {
    setOptions((prev) => prev.map((o, i) => (i === index ? { ...o, latex } : o)));
  };

  const addOption = () => {
    setOptions((prev) => [...prev, { label: String.fromCharCode(65 + prev.length), latex: "" }]);
  };

  const removeOption = (index: number) => {
    setOptions((prev) => prev.filter((_, i) => i !== index).map((o, i) => ({ ...o, label: String.fromCharCode(65 + i) })));
  };

  const handleInsert = useCallback((text: string, wrap?: boolean) => {
    const el = activeRef.current;
    if (!el) return;
    const start = el.selectionStart, end = el.selectionEnd;
    const before = el.value.substring(0, start);
    const selected = el.value.substring(start, end);
    const after = el.value.substring(end);
    let inserted: string;
    if (wrap && selected) {
      const parts = text.split("$");
      inserted = parts[0] + selected + parts[1];
    } else if (wrap) {
      const parts = text.split("$");
      inserted = parts.join("|");
      const cursorPos = inserted.indexOf("|");
      inserted = inserted.replace("|", "");
      el.value = before + inserted + after;
      el.selectionStart = el.selectionEnd = start + cursorPos;
      el.focus();
      if (el === stemRef.current) setStemLatex(el.value);
      else if (el === solutionRef.current) setSolution(el.value);
      return;
    } else {
      inserted = text;
    }
    el.value = before + inserted + after;
    el.selectionStart = el.selectionEnd = start + inserted.length;
    el.focus();
    if (el === stemRef.current) setStemLatex(el.value);
    else if (el === solutionRef.current) setSolution(el.value);
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!stemLatex.trim()) { setError("请输入题干"); return; }
    if (!answer.trim()) { setError("请输入答案"); return; }

    setSubmitting(true);
    try {
      const res = await fetch("/api/admin/questions?id=" + questionId, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type, difficulty,
          year: year ? parseInt(year) : null,
          source: source || null,
          stemLatex,
          options: type === "choice" ? JSON.stringify(options.filter((o) => o.latex.trim())) : null,
          answer,
          solution: solution || null,
          chapterId: chapterId ? parseInt(chapterId) : null,
          knowledgePointIds: selectedKpIds,
          images: JSON.stringify(uploadedImages),
        }),
      });

      if (!res.ok) throw new Error(await res.text());
      router.push("/admin/questions");
      router.refresh();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "保存失败");
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
        <span className="ml-2 text-muted-foreground">加载题目数据...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">编辑题目</h1>
          <p className="text-sm text-muted-foreground mt-1">ID: {questionId} · 状态: {status === "approved" ? "已通过" : status === "pending" ? "待审核" : "已驳回"}</p>
        </div>
        <Link href="/admin/questions">
          <Button variant="outline" size="sm"><ArrowLeft className="size-4 mr-1.5" />返回列表</Button>
        </Link>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* 基本信息 */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-base">基本信息</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <label className="text-sm font-medium mb-1 block">题型</label>
              <select value={type} onChange={(e) => setType(e.target.value)} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
                {TYPE_OPTIONS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">难度</label>
              <select value={difficulty} onChange={(e) => setDifficulty(parseInt(e.target.value))} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
                {[1, 2, 3, 4, 5].map((d) => <option key={d} value={d}>{"★".repeat(d)}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">年份</label>
              <Input value={year} onChange={(e) => setYear(e.target.value)} placeholder="如 2024" />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">来源</label>
              <Input value={source} onChange={(e) => setSource(e.target.value)} placeholder="如 高考全国Ⅰ卷" />
            </div>
          </CardContent>
        </Card>

        {/* 题干 */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-base">题干 (LaTeX)</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <MathToolbar onInsert={handleInsert} />
            <ImageUploadButton onInsert={(url) => { if (stemRef.current) { activeRef.current = stemRef.current; handleInsert(url); } setUploadedImages(prev => [...prev, url]); }} />
            <div className="grid gap-3 lg:grid-cols-2">
              <textarea
                ref={(el) => { stemRef.current = el; }}
                onFocus={() => { activeRef.current = stemRef.current; }}
                className="w-full h-44 font-mono text-sm border rounded-md p-3 bg-muted/30 resize-y"
                value={stemLatex}
                onChange={(e) => setStemLatex(e.target.value)}
              />
              <div className="border rounded-md p-3 bg-background overflow-auto max-h-44">
                <p className="text-xs text-muted-foreground mb-2 font-medium">实时预览</p>
                <LivePreview latex={stemLatex} className="text-sm leading-relaxed" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 选项 */}
        {type === "choice" && (
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">选项 (LaTeX)</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                {options.map((opt, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="text-sm w-6 pt-2">{opt.label}.</span>
                    <Input value={opt.latex} onChange={(e) => updateOption(i, e.target.value)} placeholder={"选项 " + opt.label + " 的 LaTeX"} className="flex-1" />
                    {options.length > 2 && (
                      <Button type="button" variant="ghost" size="icon" className="shrink-0 text-destructive" onClick={() => removeOption(i)}>
                        <Trash2 className="size-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
              <Button type="button" variant="outline" size="sm" onClick={addOption}><Plus className="size-3.5" /> 添加选项</Button>
              <div className="border rounded-md p-3 bg-background">
                <p className="text-xs text-muted-foreground mb-2 font-medium">选项预览</p>
                <div className="space-y-1 text-sm">
                  {options.filter(o => o.latex.trim()).map((opt, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="font-medium">{opt.label}.</span>
                      <LivePreview latex={opt.latex} />
                    </div>
                  ))}
                  {options.filter(o => o.latex.trim()).length === 0 && (
                    <span className="text-muted-foreground text-xs">输入选项后将在此预览...</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* 答案 & 解析 */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">答案</CardTitle></CardHeader>
            <CardContent>
              <Input value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder={type === "choice" ? "如 A" : "如 3"} />
              {answer.trim() && (
                <div className="mt-2 border rounded-md p-2 bg-background text-sm">
                  <span className="text-xs text-muted-foreground">预览：</span> <LivePreview latex={answer} />
                </div>
              )}
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">解析（可选）</CardTitle></CardHeader>
            <CardContent>
              <ImageUploadButton onInsert={(url) => { if (solutionRef.current) { activeRef.current = solutionRef.current; handleInsert(url); } setUploadedImages(prev => [...prev, url]); }} />
              <textarea
                ref={(el) => { solutionRef.current = el; }}
                onFocus={() => { activeRef.current = solutionRef.current; }}
                className="w-full h-24 font-mono text-sm border rounded-md p-3 bg-muted/30 resize-y mt-1"
                value={solution}
                onChange={(e) => setSolution(e.target.value)}
                placeholder="逐步解析，支持 LaTeX..."
              />
              {solution.trim() && (
                <div className="mt-2 border rounded-md p-2 bg-background text-sm leading-relaxed overflow-auto max-h-32">
                  <span className="text-xs text-muted-foreground">预览：</span> <LivePreview latex={solution} />
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* 知识点 */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-base">关联知识点</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <select value={chapterId} onChange={(e) => { setChapterId(e.target.value); setSelectedKpIds([]); }} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
              <option value="">-- 选择册别 --</option>
              {chapters.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            {chapterId && availableKps.length > 0 && (
              <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto">
                {availableKps.map((kp: any) => (
                  <button key={kp.id} type="button" onClick={() => toggleKp(kp.id)}
                    className={"text-xs px-2.5 py-1 rounded-full border " + (selectedKpIds.includes(kp.id) ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-muted border-border")}>
                    {kp.name}
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex items-center gap-3">
          <Button type="submit" disabled={submitting} size="lg">
            {submitting ? <Loader2 className="size-4 animate-spin mr-2" /> : <Save className="size-4 mr-2" />}
            {submitting ? "保存中..." : "保存修改"}
          </Button>
          {error && <span className="text-sm text-destructive">{error}</span>}
        </div>
      </form>
    </div>
  );
}