"use client";

import { useMemo } from "react";
import { renderMixedLatex } from "@/lib/katex-server";

type Props = {
  latex: string;
  className?: string;
};

/**
 * 客户端实时预览组件
 * 注意：renderMixedLatex 是纯函数，在客户端也可运行
 */
export function LivePreview({ latex, className }: Props) {
  const html = useMemo(() => {
    if (!latex.trim()) return "<span class='text-muted-foreground text-sm'>输入公式后将在此实时预览...</span>";
    try {
      return renderMixedLatex(latex);
    } catch {
      return "<span class='text-destructive'>渲染错误</span>";
    }
  }, [latex]);

  return (
    <div
      className={className}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}