"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp, Tag, Shuffle, Loader2 } from "lucide-react";

type QuestionData = {
  id: number;
  type: string;
  difficulty: number;
  source: string | null;
  stemHtml: string;
  optionsHtml: string | null;
  answerHtml: string;
  solutionHtml: string | null;
  chapter: { id: number; name: string } | null;
  knowledgePointNames: string[];
};

type Variant = {
  id: number;
  type: string;
  difficulty: number;
  stemLatex: string;
  chapter: { id: number; name: string } | null;
  sharedKpCount: number;
};

const typeLabels: Record<string, string> = {
  choice: "选择题",
  fill: "填空题",
  short_answer: "解答题",
  proof: "证明题",
};

const typeColors: Record<string, string> = {
  choice: "bg-blue-50 text-blue-600 border-blue-200",
  fill: "bg-emerald-50 text-emerald-600 border-emerald-200",
  short_answer: "bg-purple-50 text-purple-600 border-purple-200",
  proof: "bg-amber-50 text-amber-600 border-amber-200",
};

export function QuestionCard({ question }: { question: QuestionData }) {
  const [showSolution, setShowSolution] = useState(false);
  const [showVariants, setShowVariants] = useState(false);
  const [variants, setVariants] = useState<Variant[]>([]);
  const [loadingVariants, setLoadingVariants] = useState(false);

  const { id, type, difficulty, source, stemHtml, optionsHtml, answerHtml, solutionHtml, chapter, knowledgePointNames } = question;

  async function loadVariants() {
    if (showVariants) { setShowVariants(false); return; }
    if (variants.length > 0) { setShowVariants(true); return; }
    setLoadingVariants(true);
    try {
      const res = await fetch("/api/questions/variants?questionId=" + id);
      const data = await res.json();
      setVariants(data);
      setShowVariants(true);
    } catch { /* ignore */ }
    finally { setLoadingVariants(false); }
  }

  return (
    <Card className="question-card border">
      <CardContent className="pt-4 space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className={"text-xs font-medium px-2 py-0.5 rounded border " + (typeColors[type] || "bg-gray-50 text-gray-600 border-gray-200")}>
            {typeLabels[type] || type}
          </span>
          <span className="text-xs text-amber-500">{Array(difficulty).fill("★").join("")}</span>
          {source && <span className="text-xs text-muted-foreground bg-muted/50 px-2 py-0.5 rounded">{source}</span>}
          {chapter && <span className="text-xs text-muted-foreground">{chapter.name}</span>}
        </div>

        <div className="text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: stemHtml }} />

        {optionsHtml && (
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 p-3 bg-muted/30 rounded-lg" dangerouslySetInnerHTML={{ __html: optionsHtml }} />
        )}

        {knowledgePointNames.length > 0 && (
          <div className="flex flex-wrap items-center gap-1">
            <Tag className="size-3 text-muted-foreground" />
            {knowledgePointNames.map((name) => (
              <span key={name} className="text-xs text-muted-foreground bg-muted/50 px-1.5 py-0.5 rounded">{name}</span>
            ))}
          </div>
        )}

        <div className="flex items-center gap-2 text-sm border-t pt-2.5">
          <span className="font-medium shrink-0 text-primary">答案：</span>
          <span dangerouslySetInnerHTML={{ __html: answerHtml }} />
        </div>

        {solutionHtml && (
          <div>
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setShowSolution(!showSolution)}>
              {showSolution ? <><ChevronUp className="size-3" /> 收起解析</> : <><ChevronDown className="size-3" /> 查看解析</>}
            </Button>
            {showSolution && (
              <div className="mt-2 p-3 bg-muted/30 rounded-lg text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: solutionHtml }} />
            )}
          </div>
        )}

        <div className="border-t pt-2">
          <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={loadVariants} disabled={loadingVariants}>
            {loadingVariants ? <><Loader2 className="size-3 animate-spin" /> 加载中...</>
              : showVariants ? <><ChevronUp className="size-3" /> 收起变式题</>
                : <><Shuffle className="size-3" /> 同类变式题</>}
          </Button>
          {showVariants && variants.length > 0 && (
            <div className="mt-2 space-y-2 pl-3 border-l-2 border-muted">
              {variants.map((v) => (
                <div key={v.id} className="text-sm space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={"text-xs px-1.5 py-0.5 rounded border " + (typeColors[v.type] || "bg-gray-50")}>{typeLabels[v.type] || v.type}</span>
                    <span className="text-xs text-muted-foreground">{Array(v.difficulty).fill("★").join("")} 共享{v.sharedKpCount}知识点</span>
                  </div>
                  <span className="text-muted-foreground">{v.stemLatex.replace(/\\[\(\)]/g, "").substring(0, 80)}...</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}