import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const ADMIN_COOKIE = "admin_token";
const USER_COOKIE = "user_token";

function verifyAdminToken(token: string): boolean {
  try {
    const data = atob(token);
    const [password, ts] = data.split(":");
    const adminPassword = process.env.ADMIN_PASSWORD;
    if (!adminPassword || password !== adminPassword) return false;
    if (Date.now() - parseInt(ts) > 24 * 60 * 60 * 1000) return false;
    return true;
  } catch {
    return false;
  }
}

function verifyUserTokenBasic(token: string): boolean {
  try {
    const data = atob(token);
    const [userId, ts] = data.split(":");
    if (!userId || !ts) return false;
    if (Date.now() - parseInt(ts) > 7 * 24 * 60 * 60 * 1000) return false;
    return true;
  } catch {
    return false;
  }
}

export async function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname;

  // 公开路由
  if (
    pathname === "/login" ||
    pathname === "/register" ||
    pathname.startsWith("/api/auth/")
  ) {
    return NextResponse.next();
  }

  // 管理员登录
  if (pathname === "/admin/login" || pathname === "/api/admin/login" || pathname === "/api/admin/logout") {
    return NextResponse.next();
  }

  // 管理员路由
  if (pathname.startsWith("/admin") || pathname.startsWith("/api/admin")) {
    const token = request.cookies.get(ADMIN_COOKIE)?.value;
    if (!token || !verifyAdminToken(token)) {
      if (pathname.startsWith("/api/")) {
        return NextResponse.json({ error: "未授权" }, { status: 401 });
      }
      return NextResponse.redirect(new URL("/admin/login", request.url));
    }
    return NextResponse.next();
  }

  // 用户路由（题库、投稿等）
  const isUserRoute =
    pathname.startsWith("/questions") ||
    pathname.startsWith("/papers") ||
    pathname.startsWith("/submit") ||
    pathname.startsWith("/api/questions") ||
    pathname.startsWith("/api/papers");

  if (isUserRoute) {
    // 管理员可直接访问
    const adminToken = request.cookies.get(ADMIN_COOKIE)?.value;
    if (adminToken && verifyAdminToken(adminToken)) {
      return NextResponse.next();
    }

    // 普通用户
    const userToken = request.cookies.get(USER_COOKIE)?.value;
    if (userToken && verifyUserTokenBasic(userToken)) {
      return NextResponse.next();
    }

    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 });
    }
    return NextResponse.redirect(new URL("/login", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/admin/:path*",
    "/api/admin/:path*",
    "/questions/:path*",
    "/papers/:path*",
    "/submit",
    "/api/questions/:path*",
    "/api/papers/:path*",
    "/login",
    "/register",
  ],
};