import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-6">
            <Link href="/admin" className="font-bold text-lg text-primary">
              ⚙️ 管理后台
            </Link>
            <nav className="flex items-center gap-1 text-sm">
              <Link href="/admin" className="px-3 py-1.5 rounded-md hover:bg-muted transition-colors">总览</Link>
              <Link href="/admin/chapters" className="px-3 py-1.5 rounded-md hover:bg-muted transition-colors">章节</Link>
              <Link href="/admin/questions" className="px-3 py-1.5 rounded-md hover:bg-muted transition-colors">题目管理</Link>
            </nav>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/" className="text-sm text-muted-foreground hover:text-foreground">返回首页</Link>
            <form action="/api/admin/logout" method="POST">
              <Button variant="ghost" size="sm" type="submit">退出</Button>
            </form>
          </div>
        </div>
      </header>
      <main className="container mx-auto p-6">{children}</main>
    </div>
  );
}