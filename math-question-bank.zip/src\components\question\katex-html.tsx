﻿import { renderMixedLatex } from "@/lib/katex-server";

type Props = {
  latex: string;
  className?: string;
};

/**
 * KaTeX 服务端渲染组件
 * 在服务端将 LaTeX 转为 HTML，浏览器零 JS 即可显示
 */
export function KatexHtml({ latex, className }: Props) {
  const html = renderMixedLatex(latex);

  return (
    <span
      className={className}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
