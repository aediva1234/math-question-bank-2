"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DeleteButton } from "@/components/admin/delete-btn";
import { Check, X, Clock, Loader2, Pencil } from "lucide-react";

type Question = {
  id: number;
  type: string;
  difficulty: number;
  status: string;
  stemLatex: string;
  chapter: { id: number; name: string } | null;
  submittedBy: { id: number; name: string; email: string } | null;
  knowledgePoints: { knowledgePoint: { id: number; name: string } }[];
};

const typeLabels: Record<string, string> = {
  choice: "选择题",
  fill: "填空题",
  short_answer: "解答题",
  proof: "证明题",
};

const statusLabels: Record<string, { label: string; cls: string }> = {
  approved: { label: "已通过", cls: "bg-emerald-100 text-emerald-700" },
  pending: { label: "待审核", cls: "bg-yellow-100 text-yellow-700" },
  rejected: { label: "已驳回", cls: "bg-red-100 text-red-700" },
};

export default function AdminQuestionsPage() {
  const [filter, setFilter] = useState<"all" | "pending" | "approved">("all");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [acting, setActing] = useState<number | null>(null);

  const fetchQuestions = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (filter !== "all") params.set("status", filter);
    const res = await fetch("/api/admin/questions?" + params.toString());
    const data = await res.json();
    setQuestions(data);
    setLoading(false);
  }, [filter]);

  useEffect(() => { fetchQuestions(); }, [fetchQuestions]);

  async function handleApprove(id: number) {
    setActing(id);
    await fetch("/api/admin/questions?id=" + id, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "approved" }),
    });
    setActing(null);
    setQuestions((prev) => prev.map((q) => (q.id === id ? { ...q, status: "approved" } : q)));
  }

  async function handleReject(id: number) {
    setActing(id);
    await fetch("/api/admin/questions?id=" + id, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "rejected" }),
    });
    setActing(null);
    setQuestions((prev) => prev.map((q) => (q.id === id ? { ...q, status: "rejected" } : q)));
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">题目管理</h1>
          <p className="text-sm text-muted-foreground mt-1">共 {questions.length} 道题目</p>
        </div>
        <Link href="/admin/questions/new">
          <Button>+ 添加题目</Button>
        </Link>
      </div>

      <div className="flex items-center gap-2">
        {(["all", "pending", "approved"] as const).map((f) => (
          <Button key={f} variant={filter === f ? "default" : "outline"} size="sm" onClick={() => setFilter(f)}>
            {f === "all" ? "全部" : f === "pending" ? "待审核" : "已通过"}
          </Button>
        ))}
      </div>

      {loading ? (
        <div className="py-12 text-center text-muted-foreground">
          <Loader2 className="size-5 animate-spin inline" /> 加载中...
        </div>
      ) : questions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground space-y-2">
            <p>暂无题目</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {questions.map((q) => {
            const status = statusLabels[q.status] || statusLabels.approved;
            return (
              <Card key={q.id} className="hover:bg-muted/30 transition-colors">
                <CardContent className="py-3 flex items-center gap-3">
                  <span className={"text-xs font-medium px-2 py-0.5 rounded shrink-0 " + (
                    q.type === "choice" ? "bg-blue-100 text-blue-700"
                    : q.type === "fill" ? "bg-green-100 text-green-700"
                    : "bg-purple-100 text-purple-700"
                  )}>
                    {typeLabels[q.type] || q.type}
                  </span>
                  <span className={"text-xs font-medium px-2 py-0.5 rounded shrink-0 " + status.cls}>
                    {status.label}
                  </span>
                  <span className="text-sm truncate flex-1 min-w-0">
                    {q.stemLatex.replace(/\$\$/g, "").replace(/\$/g, "").substring(0, 60)}
                    {q.stemLatex.length > 60 ? "..." : ""}
                  </span>
                  <span className="text-xs text-muted-foreground shrink-0 hidden sm:inline">
                    {q.chapter?.name || "未分类"}
                  </span>
                  <span className="text-xs shrink-0">{"★".repeat(q.difficulty)}</span>
                  {q.submittedBy && (
                    <span className="text-xs text-muted-foreground shrink-0 hidden lg:inline" title={q.submittedBy.email}>
                      由 {q.submittedBy.name} 提交
                    </span>
                  )}
                  <div className="flex items-center gap-1 shrink-0">
                    <Link href={"/admin/questions/" + q.id + "/edit"}>
                      <Button size="sm" variant="ghost" className="h-7 text-xs" title="编辑">
                        <Pencil className="size-3.5" />
                      </Button>
                    </Link>
                    {q.status === "pending" && (
                      <>
                        <Button size="sm" variant="ghost" className="h-7 text-xs text-emerald-600 hover:text-emerald-700" onClick={() => handleApprove(q.id)} disabled={acting === q.id}>
                          {acting === q.id ? <Loader2 className="size-3 animate-spin" /> : <Check className="size-3.5" />}
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 text-xs text-red-600 hover:text-red-700" onClick={() => handleReject(q.id)} disabled={acting === q.id}>
                          <X className="size-3.5" />
                        </Button>
                      </>
                    )}
                    <DeleteButton questionId={q.id} onDeleted={fetchQuestions} />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}