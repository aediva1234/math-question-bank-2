import { prisma } from "@/lib/prisma";
import { ChapterEditor } from "@/components/admin/chapter-editor";

export const dynamic = "force-dynamic";

export default async function ChaptersPage() {
  const chapters = await prisma.chapter.findMany({
    orderBy: { order: "asc" },
    include: {
      sections: {
        orderBy: { order: "asc" },
        include: {
          knowledgePoints: { orderBy: { id: "asc" } },
        },
      },
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">章节管理</h1>
        <p className="text-sm text-muted-foreground mt-1">
          管理教材册、章（节）、知识点。修改会立即生效。
        </p>
      </div>
      <ChapterEditor chapters={JSON.parse(JSON.stringify(chapters))} />
    </div>
  );
}