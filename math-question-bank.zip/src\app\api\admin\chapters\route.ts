import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET - 获取全部章节树
export async function GET() {
  const chapters = await prisma.chapter.findMany({
    orderBy: { order: "asc" },
    include: {
      sections: {
        orderBy: { order: "asc" },
        include: {
          knowledgePoints: { orderBy: { id: "asc" } },
        },
      },
    },
  });
  return NextResponse.json(chapters);
}

// POST - 添加章节/节/知识点
export async function POST(request: NextRequest) {
  const body = await request.json();
  const type = body.type || "chapter";

  if (type === "chapter") {
    const count = await prisma.chapter.count();
    const chapter = await prisma.chapter.create({
      data: { name: body.name, order: (count + 1) * 10 },
    });
    return NextResponse.json(chapter);
  }

  if (type === "section") {
    const count = await prisma.section.count({
      where: { chapterId: body.chapterId },
    });
    const section = await prisma.section.create({
      data: {
        name: body.name,
        chapterId: body.chapterId,
        order: (count + 1) * 10,
      },
    });
    return NextResponse.json(section);
  }

  if (type === "kp") {
    const kp = await prisma.knowledgePoint.create({
      data: { name: body.name, sectionId: body.sectionId },
    });
    return NextResponse.json(kp);
  }

  return NextResponse.json({ error: "无效类型" }, { status: 400 });
}

// PATCH - 更新章节/节/知识点
export async function PATCH(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = parseInt(searchParams.get("id") || "0");
  const body = await request.json();
  const type = body.type || "chapter";

  if (type === "chapter") {
    await prisma.chapter.update({ where: { id }, data: { name: body.name } });
  } else if (type === "section") {
    await prisma.section.update({ where: { id }, data: { name: body.name } });
  } else if (type === "kp") {
    await prisma.knowledgePoint.update({ where: { id }, data: { name: body.name } });
  }

  return NextResponse.json({ success: true });
}

// DELETE - 删除章节/节/知识点
export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = parseInt(searchParams.get("id") || "0");
  const type = searchParams.get("type") || "chapter";

  if (type === "chapter") {
    await prisma.chapter.delete({ where: { id } });
  } else if (type === "section") {
    await prisma.section.delete({ where: { id } });
  } else if (type === "kp") {
    await prisma.knowledgePoint.delete({ where: { id } });
  }

  return NextResponse.json({ success: true });
}