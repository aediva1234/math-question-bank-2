import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const search = searchParams.get("search") || "";
  const chapterId = searchParams.get("chapterId");
  const kpId = searchParams.get("kpId");
  const type = searchParams.get("type");
  const difficulty = searchParams.get("difficulty");
  const status = searchParams.get("status");

  const where: Record<string, unknown> = {};

  if (search) {
    where.stemLatex = { contains: search };
  }
  if (chapterId) {
    where.chapterId = parseInt(chapterId);
  }
  if (type) {
    where.type = type;
  }
  if (difficulty) {
    where.difficulty = parseInt(difficulty);
  }
  if (kpId) {
    where.knowledgePoints = {
      some: { knowledgePointId: parseInt(kpId) },
    };
  }
  const idParam = searchParams.get("id");
  if (idParam) { where.id = parseInt(idParam); }
  if (status) {
    where.status = status;
  }

  const questions = await prisma.question.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      chapter: true,
      submittedBy: { select: { id: true, name: true, email: true } },
      knowledgePoints: { include: { knowledgePoint: { include: { section: true } } } },
    },
  });

  return NextResponse.json(questions);
}

export async function POST(request: NextRequest) {
  const body = await request.json();

  const question = await prisma.question.create({
    data: {
      type: body.type,
      difficulty: body.difficulty || 1,
      year: body.year || null,
      source: body.source || null,
      stemLatex: body.stemLatex,
      options: body.options || null,
      answer: body.answer,
      solution: body.solution || null,
      chapterId: body.chapterId || null,
      images: body.images || "[]",
      status: body.status || "approved",
      submittedById: body.submittedById || null,
    },
  });

  if (body.knowledgePointIds && Array.isArray(body.knowledgePointIds)) {
    for (const kpId of body.knowledgePointIds) {
      await prisma.questionKnowledgePoint.create({
        data: { questionId: question.id, knowledgePointId: kpId },
      });
    }
  }

  return NextResponse.json(question, { status: 201 });
}

export async function PATCH(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = parseInt(searchParams.get("id") || "0");
  const body = await request.json();

  await prisma.question.update({
    where: { id },
    data: {
      type: body.type,
      difficulty: body.difficulty,
      year: body.year,
      source: body.source,
      stemLatex: body.stemLatex,
      options: body.options,
      answer: body.answer,
      solution: body.solution,
      chapterId: body.chapterId,
      images: body.images || "[]",
    },
  });

  if (body.knowledgePointIds) {
    await prisma.questionKnowledgePoint.deleteMany({ where: { questionId: id } });
    for (const kpId of body.knowledgePointIds) {
      await prisma.questionKnowledgePoint.create({
        data: { questionId: id, knowledgePointId: kpId },
      });
    }
  }

  return NextResponse.json({ success: true });
}

export async function PUT(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = parseInt(searchParams.get("id") || "0");
  const body = await request.json();

  await prisma.question.update({
    where: { id },
    data: { status: body.status },
  });

  return NextResponse.json({ success: true });
}

export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = parseInt(searchParams.get("id") || "0");

  await prisma.question.delete({ where: { id } });
  return NextResponse.json({ success: true });
}