/**
 * 题目整体解析器
 * 从粘贴的整段文本中自动识别：题干、选项(A/B/C/D)、答案、解析
 */
export interface ParsedQuestion {
  stemLatex: string;
  options: { label: string; latex: string }[];
  answer: string;
  solution: string;
}

export function parseFullQuestion(raw: string): ParsedQuestion {
  const text = raw.trim();

  // 1. 找答案行
  const answerPatterns = [
    /(?:^|\n)\s*【?答案】?\s*[：:]\s*(.+?)(?:\n|$)/i,
    /(?:^|\n)\s*参考答案\s*[：:]\s*(.+?)(?:\n|$)/i,
    /(?:^|\n)\s*答案\s*[：:]\s*(.+?)(?:\n|$)/i,
  ];

  let answer = "";
  let answerEnd = text.length;
  for (const pat of answerPatterns) {
    const m = text.match(pat);
    if (m) {
      answer = m[1].trim();
      answerEnd = m.index!;
      break;
    }
  }

  // 2. 找解析行
  const solutionPatterns = [
    /(?:^|\n)\s*【?解析】?\s*[：:]/i,
    /(?:^|\n)\s*【?分析】?\s*[：:]/i,
    /(?:^|\n)\s*【?详解】?\s*[：:]/i,
    /(?:^|\n)\s*解析\s*[：:]/i,
    /(?:^|\n)\s*分析\s*[：:]/i,
  ];

  let solution = "";
  let solutionStart = -1;
  for (const pat of solutionPatterns) {
    const m = text.match(pat);
    if (m && m.index! < answerEnd) {
      solutionStart = m.index!;
      solution = answerEnd < text.length
        ? text.slice(m.index! + m[0].length, answerEnd).trim()
        : text.slice(m.index! + m[0].length).trim();
      break;
    }
  }

  // 3. 主题干（去掉解析和答案部分）
  let mainText = text;
  if (solutionStart >= 0) {
    mainText = text.slice(0, solutionStart);
  } else if (answerEnd < text.length) {
    mainText = text.slice(0, answerEnd);
  }

  // 4. 从主题干中拆出选项
  // 用 [\s\S] 替代 . 避免 ES2018 s 标志依赖
  const optLinePattern = /(?:^|\n)\s*([A-H])[.．、)]\s*([\s\S]+?)(?=\n\s*[A-H][.．、)]|\n\s*(?:答案|解析|【|$))/g;
  const options: { label: string; latex: string }[] = [];
  let stemLatex = mainText;

  let match: RegExpExecArray | null;
  while ((match = optLinePattern.exec(mainText)) !== null) {
    if (options.length === 0) {
      stemLatex = mainText.slice(0, match.index).trim();
      stemLatex = stemLatex.replace(/\s*[（(]\s*[）)]\s*$/, "");
    }
    options.push({ label: match[1], latex: match[2].trim() });
  }

  // 没找到选项：尝试用空行分割再找
  if (options.length === 0) {
    stemLatex = mainText.trim();
    const parts = mainText.split(/\n\s*\n/);
    if (parts.length >= 2) {
      stemLatex = parts[0].trim();
      const rest = parts.slice(1).join("\n\n");
      const lines = rest.split("\n");
      for (const line of lines) {
        const pm = line.match(/^\s*([A-H])[.．、)]\s*(.+)/);
        if (pm) options.push({ label: pm[1], latex: pm[2].trim() });
      }
    }
  }

  return { stemLatex, options, answer, solution };
}