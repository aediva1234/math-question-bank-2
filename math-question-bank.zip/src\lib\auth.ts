import { prisma } from "./prisma";
import bcrypt from "bcryptjs";

const ADMIN_COOKIE = "admin_token";
const USER_COOKIE = "user_token";

/** 验证管理员 token */
export function verifyAdminToken(token: string): boolean {
  try {
    const data = Buffer.from(token, "base64").toString();
    const [password, ts] = data.split(":");
    const adminPassword = process.env.ADMIN_PASSWORD;
    if (!adminPassword || password !== adminPassword) return false;
    if (Date.now() - parseInt(ts) > 24 * 60 * 60 * 1000) return false;
    return true;
  } catch {
    return false;
  }
}

/** 验证普通用户 token */
export async function verifyUserToken(token: string) {
  try {
    const data = Buffer.from(token, "base64").toString();
    const [userId, ts] = data.split(":");
    if (Date.now() - parseInt(ts) > 7 * 24 * 60 * 60 * 1000) return null;
    const user = await prisma.user.findUnique({ where: { id: parseInt(userId) } });
    if (!user || user.status !== "active") return null;
    return user;
  } catch {
    return null;
  }
}

/** 生成管理员 token */
export function createAdminToken(password: string): string {
  const ts = Date.now().toString();
  return Buffer.from(password + ":" + ts).toString("base64");
}

/** 生成用户 token */
export function createUserToken(userId: number): string {
  const ts = Date.now().toString();
  return Buffer.from(userId + ":" + ts).toString("base64");
}

/** 哈希密码 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

/** 验证密码 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export { ADMIN_COOKIE, USER_COOKIE };