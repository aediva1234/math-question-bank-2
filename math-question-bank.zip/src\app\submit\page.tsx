"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MathToolbar } from "@/components/admin/math-toolbar";
import { LivePreview } from "@/components/question/live-preview";
import { ImageUploadButton } from "@/components/admin/image-upload";
import { Plus, Trash2, Loader2, Send, CheckCircle } from "lucide-react";

const TYPE_OPTIONS = [
  { value: "choice", label: "选择题" },
  { value: "fill", label: "填空题" },
  { value: "short_answer", label: "解答题" },
  { value: "proof", label: "证明题" },
];

export default function SubmitPage() {
  const router = useRouter();
  const [type, setType] = useState("choice");
  const [difficulty, setDifficulty] = useState(3);
  const [year, setYear] = useState("");
  const [source, setSource] = useState("");
  const [stemLatex, setStemLatex] = useState("");
  const [options, setOptions] = useState([
    { label: "A", latex: "" },
    { label: "B", latex: "" },
    { label: "C", latex: "" },
    { label: "D", latex: "" },
  ]);
  const [answer, setAnswer] = useState("");
  const [solution, setSolution] = useState("");
  const [chapterId, setChapterId] = useState("");
  const [selectedKpIds, setSelectedKpIds] = useState<number[]>([]);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const [chapters, setChapters] = useState<any[]>([]);
  const stemRef = { current: null as HTMLTextAreaElement | null };

  useEffect(() => {
    fetch("/api/admin/chapters")
      .then((r) => r.json())
      .then(setChapters)
      .catch(() => {});
  }, []);

  const availableKps = chapterId
    ? chapters.find((c: any) => c.id === parseInt(chapterId))?.sections?.flatMap((s: any) => s.knowledgePoints) || []
    : [];

  const toggleKp = (kpId: number) => {
    setSelectedKpIds((prev) => (prev.includes(kpId) ? prev.filter((id) => id !== kpId) : [...prev, kpId]));
  };

  const updateOption = (index: number, latex: string) => {
    setOptions((prev) => prev.map((o, i) => (i === index ? { ...o, latex } : o)));
  };

  const addOption = () => {
    const label = String.fromCharCode(65 + options.length);
    setOptions((prev) => [...prev, { label, latex: "" }]);
  };

  const removeOption = (index: number) => {
    setOptions((prev) =>
      prev.filter((_, i) => i !== index).map((o, i) => ({ ...o, label: String.fromCharCode(65 + i) }))
    );
  };

  function handleInsert(text: string, _wrap?: boolean) {
    const el = stemRef.current;
    if (!el) return;
    const start = el.selectionStart, end = el.selectionEnd;
    const before = el.value.substring(0, start);
    const after = el.value.substring(end);
    el.value = before + text + after;
    el.selectionStart = el.selectionEnd = start + text.length;
    el.focus();
    setStemLatex(el.value);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!stemLatex.trim()) { setError("请输入题干"); return; }
    if (!answer.trim()) { setError("请输入答案"); return; }

    setSubmitting(true);
    try {
      const res = await fetch("/api/questions/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type, difficulty,
          year: year ? parseInt(year) : null,
          source: source || null,
          stemLatex,
          options: type === "choice" ? JSON.stringify(options.filter((o) => o.latex.trim())) : null,
          answer,
          solution: solution || null,
          chapterId: chapterId ? parseInt(chapterId) : null,
          knowledgePointIds: selectedKpIds,
          images: JSON.stringify(uploadedImages),
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || "提交失败");
        return;
      }

      setSuccess(true);
    } catch {
      setError("网络错误，请重试");
    } finally {
      setSubmitting(false);
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center px-4">
        <Card className="w-full max-w-md text-center">
          <CardContent className="py-12 space-y-4">
            <CheckCircle className="size-12 text-emerald-500 mx-auto" />
            <h2 className="text-xl font-bold">提交成功！</h2>
            <p className="text-sm text-muted-foreground">题目已提交，管理员审核通过后即可在题库中看到。</p>
            <div className="flex gap-3 justify-center">
              <Button variant="outline" onClick={() => { setSuccess(false); setStemLatex(""); setAnswer(""); setSolution(""); setOptions([{label:"A",latex:""},{label:"B",latex:""},{label:"C",latex:""},{label:"D",latex:""}]); }}>
                继续投稿
              </Button>
              <Button onClick={() => router.push("/questions")}>浏览题库</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-background sticky top-0 z-10">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <h1 className="font-bold text-lg">📝 投稿题目</h1>
          <div className="flex items-center gap-3 text-sm">
            <span className="text-muted-foreground">提交后需管理员审核</span>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-3xl p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">基本信息</CardTitle></CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="text-sm font-medium mb-1 block">题型</label>
                <select value={type} onChange={(e) => setType(e.target.value)} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
                  {TYPE_OPTIONS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">难度</label>
                <select value={difficulty} onChange={(e) => setDifficulty(parseInt(e.target.value))} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
                  {[1, 2, 3, 4, 5].map((d) => <option key={d} value={d}>{"★".repeat(d)}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">年份</label>
                <Input value={year} onChange={(e) => setYear(e.target.value)} placeholder="如 2024" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">来源</label>
                <Input value={source} onChange={(e) => setSource(e.target.value)} placeholder="如 高考全国Ⅰ卷" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">题干 (LaTeX)</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <MathToolbar onInsert={handleInsert} />
              <div className="flex items-center gap-2">
                <ImageUploadButton onInsert={(url) => { handleInsert(url); setUploadedImages(prev => [...prev, url]); }} />
                <span className="text-xs text-muted-foreground">可插入图片</span>
              </div>
              <textarea
                ref={(el) => { stemRef.current = el; }}
                className="w-full h-40 font-mono text-sm border rounded-md p-3 bg-muted/30 resize-y"
                placeholder="输入题干 LaTeX，如：已知抛物线 \(y^2 = 2px\) 经过点 \((4,8)\)，则..."
                value={stemLatex}
                onChange={(e) => setStemLatex(e.target.value)}
              />
              <div className="border rounded-md p-3 bg-background">
                <p className="text-xs text-muted-foreground mb-2 font-medium">实时预览</p>
                <LivePreview latex={stemLatex} className="text-sm leading-relaxed" />
              </div>
            </CardContent>
          </Card>

          {type === "choice" && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">选项</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {options.map((opt, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="text-sm w-6">{opt.label}.</span>
                    <Input value={opt.latex} onChange={(e) => updateOption(i, e.target.value)} placeholder={"选项 " + opt.label} className="flex-1" />
                    {options.length > 2 && (
                      <Button type="button" variant="ghost" size="icon" className="shrink-0 text-destructive" onClick={() => removeOption(i)}>
                        <Trash2 className="size-4" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button type="button" variant="outline" size="sm" onClick={addOption}>
                  <Plus className="size-3.5" /> 添加选项
                </Button>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">答案</CardTitle></CardHeader>
              <CardContent>
                <Input value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder={type === "choice" ? "如 A" : "如 3"} />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">解析（可选）</CardTitle></CardHeader>
              <CardContent>
                <textarea className="w-full h-24 font-mono text-sm border rounded-md p-3 bg-muted/30 resize-y" value={solution} onChange={(e) => setSolution(e.target.value)} placeholder="逐步解析..." />
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">分类（可选）</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <select value={chapterId} onChange={(e) => { setChapterId(e.target.value); setSelectedKpIds([]); }} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
                <option value="">-- 选择册别 --</option>
                {chapters.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              {chapterId && availableKps.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {availableKps.map((kp: any) => (
                    <button key={kp.id} type="button" onClick={() => toggleKp(kp.id)}
                      className={"text-xs px-2.5 py-1 rounded-full border " + (selectedKpIds.includes(kp.id) ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-muted border-border")}>
                      {kp.name}
                    </button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex items-center gap-3">
            <Button type="submit" disabled={submitting} size="lg">
              {submitting ? <Loader2 className="size-4 animate-spin mr-2" /> : <Send className="size-4 mr-2" />}
              {submitting ? "提交中..." : "提交审核"}
            </Button>
            {error && <span className="text-sm text-destructive">{error}</span>}
          </div>
        </form>
      </main>
    </div>
  );
}