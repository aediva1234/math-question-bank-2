import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyUserToken, USER_COOKIE } from "@/lib/auth";

export async function POST(request: NextRequest) {
  const token = request.cookies.get(USER_COOKIE)?.value;
  if (!token) {
    return NextResponse.json({ error: "请先登录" }, { status: 401 });
  }

  const user = await verifyUserToken(token);
  if (!user) {
    return NextResponse.json({ error: "登录已过期，请重新登录" }, { status: 401 });
  }

  try {
    const body = await request.json();

    if (!body.stemLatex?.trim() || !body.answer?.trim()) {
      return NextResponse.json({ error: "题干和答案不能为空" }, { status: 400 });
    }

    const question = await prisma.question.create({
      data: {
        type: body.type || "fill",
        difficulty: body.difficulty || 3,
        year: body.year || null,
        source: body.source || null,
        stemLatex: body.stemLatex,
        options: body.options || null,
        answer: body.answer,
        solution: body.solution || null,
        chapterId: body.chapterId || null,
        images: body.images || "[]",
        status: "pending",
        submittedById: user.id,
      },
    });

    if (body.knowledgePointIds && Array.isArray(body.knowledgePointIds)) {
      for (const kpId of body.knowledgePointIds) {
        await prisma.questionKnowledgePoint.create({
          data: { questionId: question.id, knowledgePointId: kpId },
        });
      }
    }

    return NextResponse.json({ success: true, id: question.id }, { status: 201 });
  } catch (e) {
    console.error("Submit error:", e);
    return NextResponse.json({ error: "提交失败" }, { status: 500 });
  }
}