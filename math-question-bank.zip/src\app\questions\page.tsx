import { prisma } from "@/lib/prisma";
import { renderMixedLatex } from "@/lib/katex-server";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { QuestionCard } from "@/components/question/question-card";
import { Search, X, Upload, BookOpen } from "lucide-react";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{
  chapter?: string; section?: string; kp?: string; type?: string; difficulty?: string; search?: string;
}>;

function preRenderQuestion(q: {
  id: number; type: string; difficulty: number; source: string | null;
  stemLatex: string; options: string | null; answer: string; solution: string | null;
  chapter: { id: number; name: string } | null;
  knowledgePoints: { knowledgePoint: { id: number; name: string } }[];
}) {
  let optionsHtml: string | null = null;
  if (q.type === "choice" && q.options) {
    try {
      const opts: { label: string; latex: string }[] = JSON.parse(q.options);
      optionsHtml = opts
        .map((o) => '<div class="flex items-start gap-2 text-sm"><span class="font-medium">' + o.label + '.</span><span>' + renderMixedLatex(o.latex) + '</span></div>')
        .join("");
    } catch { /* ignore */ }
  }

  return {
    id: q.id, type: q.type, difficulty: q.difficulty, source: q.source,
    stemHtml: renderMixedLatex(q.stemLatex), optionsHtml,
    answerHtml: renderMixedLatex(q.answer),
    solutionHtml: q.solution ? renderMixedLatex(q.solution) : null,
    chapter: q.chapter,
    knowledgePointNames: q.knowledgePoints.map((kp) => kp.knowledgePoint.name),
  };
}

export default async function QuestionsPage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const chapterId = params.chapter ? parseInt(params.chapter) : undefined;
  const kpId = params.kp ? parseInt(params.kp) : undefined;
  const type = params.type;
  const difficulty = params.difficulty ? parseInt(params.difficulty) : undefined;
  const search = params.search || "";

  const where: Record<string, unknown> = { status: "approved" };
  if (search) where.stemLatex = { contains: search };
  if (chapterId) where.chapterId = chapterId;
  if (type) where.type = type;
  if (difficulty) where.difficulty = difficulty;
  if (kpId) where.knowledgePoints = { some: { knowledgePointId: kpId } };

  const [questions, chapters, totalCount] = await Promise.all([
    prisma.question.findMany({ where, orderBy: { createdAt: "desc" }, take: 50, include: { chapter: true, knowledgePoints: { include: { knowledgePoint: true } } } }),
    prisma.chapter.findMany({ orderBy: { order: "asc" }, include: { sections: { orderBy: { order: "asc" }, include: { knowledgePoints: { orderBy: { id: "asc" }, include: { _count: { select: { questions: true } } } } } }, _count: { select: { questions: true } } } }),
    prisma.question.count({ where }),
  ]);

  const renderedQuestions = questions.map(preRenderQuestion);
  const selectedChapter = chapterId ? chapters.find((c) => c.id === chapterId) : null;
  const typeLabels: Record<string, string> = { choice: "选择题", fill: "填空题", short_answer: "解答题", proof: "证明题" };
  const difficultyLabels = ["", "★", "★★", "★★★", "★★★★", "★★★★★"];
  const hasFilters = !!(chapterId || kpId || type || difficulty || search);

  function buildHref(overrides: Record<string, string | undefined>) {
    const p = new URLSearchParams();
    const cur: Record<string, string | undefined> = { chapter: params.chapter, kp: params.kp, type: params.type, difficulty: params.difficulty, search: params.search, ...overrides };
    Object.entries(cur).forEach(([k, v]) => { if (v) p.set(k, v); });
    return "/questions?" + p.toString();
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto flex h-14 items-center justify-between px-4">
          <Link href="/" className="flex items-center gap-2 font-bold text-lg text-primary">
            <BookOpen className="size-5" /> 高中数学题库
          </Link>
          <nav className="flex items-center gap-2 text-sm">
            <Link href="/questions" className="font-medium px-3 py-1.5 rounded-md bg-primary/10 text-primary">题库</Link>
            <Link href="/submit" className="px-3 py-1.5 rounded-md hover:bg-muted transition-colors flex items-center gap-1">
              <Upload className="size-3.5" /> 投稿
            </Link>
          </nav>
        </div>
      </header>

      <div className="container mx-auto p-6">
        <div className="flex flex-col gap-6 lg:flex-row">
          <aside className="w-full shrink-0 lg:w-56 space-y-4">
            <form action="/questions" method="GET" className="relative">
              <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
              <Input name="search" defaultValue={search} placeholder="搜索题目..." className="pl-9 text-sm h-9" />
              {params.chapter && <input type="hidden" name="chapter" value={params.chapter} />}
              {params.type && <input type="hidden" name="type" value={params.type} />}
              {params.difficulty && <input type="hidden" name="difficulty" value={params.difficulty} />}
            </form>

            <div>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">按册筛选</h3>
              <div className="space-y-0.5">
                <Link href="/questions" className={"block text-sm rounded-md px-2.5 py-1.5 transition-colors " + (!chapterId ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted")}>全部 ({totalCount})</Link>
                {chapters.map((ch) => (
                  <Link key={ch.id} href={buildHref({ chapter: String(ch.id), kp: undefined })} className={"block text-sm rounded-md px-2.5 py-1.5 transition-colors " + (chapterId === ch.id ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted")}>{ch.name} ({ch._count.questions})</Link>
                ))}
              </div>
            </div>

            {selectedChapter && (
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">知识点</h3>
                <div className="space-y-1 max-h-56 overflow-y-auto">
                  {selectedChapter.sections.map((sec) => (
                    <div key={sec.id}>
                      <p className="text-[11px] text-muted-foreground font-medium mt-2 mb-0.5 px-1">{sec.name}</p>
                      {sec.knowledgePoints.map((kp) => (
                        <Link key={kp.id} href={buildHref({ kp: String(kp.id) })} className={"block text-xs rounded-md px-2 py-1 ml-1.5 transition-colors " + (kpId === kp.id ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted")}>{kp.name} ({kp._count.questions})</Link>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">按题型</h3>
              <div className="space-y-0.5">
                {Object.entries(typeLabels).map(([key, label]) => (
                  <Link key={key} href={buildHref({ type: type === key ? undefined : key })} className={"block text-sm rounded-md px-2.5 py-1.5 transition-colors " + (type === key ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted")}>{label}</Link>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">按难度</h3>
              <div className="space-y-0.5">
                {[1, 2, 3, 4, 5].map((d) => (
                  <Link key={d} href={buildHref({ difficulty: difficulty === d ? undefined : String(d) })} className={"block text-sm rounded-md px-2.5 py-1.5 transition-colors " + (difficulty === d ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted")}>{difficultyLabels[d]}</Link>
                ))}
              </div>
            </div>

            {hasFilters && (
              <Link href="/questions" className="flex items-center gap-1 text-xs text-destructive hover:underline"><X className="size-3" /> 清除筛选</Link>
            )}
          </aside>

          <main className="flex-1 space-y-4">
            <div className="flex items-center justify-between">
              <h1 className="text-lg font-bold">
                {search ? '搜索: "' + search + '"' : "题目列表"}
                <span className="text-sm font-normal text-muted-foreground ml-2">共 {totalCount} 题</span>
              </h1>
              <Link href="/submit">
                <Button size="sm" variant="outline"><Upload className="size-3.5 mr-1.5" />投稿</Button>
              </Link>
            </div>
            {renderedQuestions.length === 0 ? (
              <Card><CardContent className="py-12 text-center text-muted-foreground space-y-2"><p>暂无匹配的题目</p>{hasFilters && <Link href="/questions"><Button variant="outline" size="sm">清除筛选</Button></Link>}</CardContent></Card>
            ) : (
              renderedQuestions.map((q) => <QuestionCard key={q.id} question={q} />)
            )}
          </main>
        </div>
      </div>
    </div>
  );
}