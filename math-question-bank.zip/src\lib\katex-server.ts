﻿import katex from "katex";

type Segment =
  | { type: "text"; content: string }
  | { type: "math"; content: string; display: boolean }
  | { type: "image"; url: string; alt: string };

function parseMixedLatex(input: string): Segment[] {
  const segments: Segment[] = [];
  const regex =
    /(!\[[^\]]*\]\([^)]+\)|\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|\$[^$\n\r]*?\$|\\\([\s\S]*?\\\))/g;

  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(input)) !== null) {
    if (match.index > lastIndex) {
      const text = input.slice(lastIndex, match.index);
      if (text) segments.push({ type: "text", content: text });
    }

    const raw = match[0];

    if (raw.startsWith("![")) {
      const altMatch = raw.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
      if (altMatch) {
        segments.push({ type: "image", alt: altMatch[1], url: altMatch[2] });
      } else {
        segments.push({ type: "text", content: raw });
      }
    } else if (raw.startsWith("$$") && raw.endsWith("$$")) {
      segments.push({ type: "math", content: raw.slice(2, -2), display: true });
    } else if (raw.startsWith("\\[") && raw.endsWith("\\]")) {
      segments.push({ type: "math", content: raw.slice(2, -2), display: true });
    } else if (raw.startsWith("$") && raw.endsWith("$")) {
      segments.push({ type: "math", content: raw.slice(1, -1), display: false });
    } else if (raw.startsWith("\\(") && raw.endsWith("\\)")) {
      segments.push({ type: "math", content: raw.slice(2, -2), display: false });
    }

    lastIndex = match.index + raw.length;
  }

  if (lastIndex < input.length) {
    segments.push({ type: "text", content: input.slice(lastIndex) });
  }

  if (segments.length === 0 && input.trim()) {
    segments.push({ type: "text", content: input });
  }

  return segments;
}

export function renderMixedLatex(input: string): string {
  if (!input) return "";

  const segments = parseMixedLatex(input);

  return segments
    .map((seg) => {
      if (seg.type === "text") {
        return escapeHtml(seg.content);
      }
      if (seg.type === "image") {
        const alt = escapeHtml(seg.alt || "");
        const url = escapeHtml(seg.url);
        return `<img src="${url}" alt="${alt}" class="question-image" loading="lazy" />`;
      }
      try {
        return katex.renderToString(seg.content, {
          displayMode: seg.display,
          throwOnError: false,
          trust: true,
        });
      } catch {
        return `<span class="katex-error">${escapeHtml(seg.content)}</span>`;
      }
    })
    .join("");
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
