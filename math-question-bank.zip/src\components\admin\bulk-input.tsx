﻿"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LivePreview } from "@/components/question/live-preview";
import { parseFullQuestion, type ParsedQuestion } from "@/lib/question-parser";
import { Wand2, ArrowRight } from "lucide-react";

type Props = {
  onApply: (parsed: ParsedQuestion) => void;
};

export function BulkInput({ onApply }: Props) {
  const [raw, setRaw] = useState("");
  const [parsed, setParsed] = useState<ParsedQuestion | null>(null);
  const [error, setError] = useState("");

  function handleParse() {
    setError("");
    if (!raw.trim()) {
      setError("请先粘贴题目内容");
      return;
    }
    try {
      const result = parseFullQuestion(raw);
      if (!result.stemLatex) {
        setError("未能识别题干，请检查格式");
        return;
      }
      if (result.options.length > 0 && result.options.length < 2) {
        setError("选择题至少需要2个选项");
        return;
      }
      setParsed(result);
    } catch (e) {
      setError("解析失败：" + (e instanceof Error ? e.message : "未知错误"));
    }
  }

  function handleApply() {
    if (parsed) onApply(parsed);
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">粘贴整道题目</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            将完整的题目文本粘贴到下方，系统会自动识别题干、选项、答案和解析。
            支持常见格式：选项以 A. B. C. D. 开头，答案以"答案："标注，解析以"解析："标注。
          </p>
          <textarea
            className="w-full h-64 font-mono text-sm border rounded-md p-3 bg-muted/30 resize-y"
            placeholder={`已知抛物线 \\(C_1: y^2 = 2p_1x\\ (p_1 > 0)\\) 和 \\(C_2: x^2 = 2p_2y\\ (p_2 > 0)\\) 均经过点 \\((4,8)\\)，则 \\(C_1\\) 的焦点与 \\(C_2\\) 的焦点之间的距离为（ ）\nA. 12\nB. \\(4\\sqrt{5}\\)\nC. 6\nD. \\(\\dfrac{\\sqrt{65}}{2}\\)\n\n答案：D\n\n解析：由 \\(C_1\\) 过 \\((4,8)\\) 得 \\(p_1=8\\)，焦点 \\(F_1(4,0)\\)...`}
            value={raw}
            onChange={(e) => { setRaw(e.target.value); setParsed(null); }}
          />
          <div className="flex items-center gap-3">
            <Button onClick={handleParse}>
              <Wand2 className="size-4 mr-1" /> 智能解析
            </Button>
            {error && <span className="text-sm text-destructive">{error}</span>}
          </div>
        </CardContent>
      </Card>

      {parsed && (
        <Card className="border-primary/50">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                解析结果
                {parsed.options.length > 0 && (
                  <span className="text-xs font-normal text-muted-foreground">
                    识别为选择题（{parsed.options.length}个选项）
                  </span>
                )}
                {parsed.options.length === 0 && (
                  <span className="text-xs font-normal text-muted-foreground">未识别选项，按填空/解答题处理</span>
                )}
              </CardTitle>
              <Button onClick={handleApply} size="sm">
                <ArrowRight className="size-3.5 mr-1" /> 填入表单
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {/* 题干 */}
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-1">📝 题干</p>
              <div className="border rounded-md p-3 bg-muted/20 text-sm leading-relaxed">
                <LivePreview latex={parsed.stemLatex} />
              </div>
            </div>

            {/* 选项 */}
            {parsed.options.length > 0 && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">📋 选项</p>
                <div className="grid grid-cols-2 gap-2">
                  {parsed.options.map((opt) => (
                    <div key={opt.label} className="border rounded-md p-2 bg-background text-sm flex items-start gap-2">
                      <span className="font-medium">{opt.label}.</span>
                      <LivePreview latex={opt.latex} />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 答案 */}
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-1">✅ 答案</p>
              <div className="border rounded-md p-2 bg-background text-sm">
                {parsed.answer ? <LivePreview latex={parsed.answer} /> : <span className="text-muted-foreground">未识别</span>}
              </div>
            </div>

            {/* 解析 */}
            {parsed.solution && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1">💡 解析</p>
                <div className="border rounded-md p-3 bg-muted/20 text-sm leading-relaxed max-h-40 overflow-auto">
                  <LivePreview latex={parsed.solution} />
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
