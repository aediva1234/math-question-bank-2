"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, BookOpen, LogIn } from "lucide-react";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirect = searchParams.get("redirect") || "/questions";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || "登录失败"); return; }
      router.push(redirect);
      router.refresh();
    } catch { setError("网络错误，请重试"); }
    finally { setLoading(false); }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-primary/5 px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
            <BookOpen className="size-6 text-primary" />
          </div>
          <h1 className="text-xl font-bold">登录题库</h1>
          <p className="text-sm text-muted-foreground mt-1">浏览和搜索数学题目</p>
        </div>

        <div className="bg-white rounded-xl border shadow-sm p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">邮箱</label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" required />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">密码</label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="至少 6 位" required />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="size-4 animate-spin mr-2" /> : <LogIn className="size-4 mr-2" />}
              登录
            </Button>
          </form>
          <p className="text-sm text-muted-foreground text-center mt-4">
            还没有账号？ <Link href="/register" className="text-primary font-medium hover:underline">免费注册</Link>
          </p>
          <div className="mt-4 pt-4 border-t text-center">
            <Link href="/admin/login" className="text-xs text-muted-foreground hover:text-foreground">管理员登录</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return <Suspense><LoginForm /></Suspense>;
}