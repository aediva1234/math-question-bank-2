﻿"use client";

import { useEffect, useRef, useMemo } from "react";
import katex from "katex";

type Props = {
  latex: string;
  className?: string;
};

type Segment =
  | { type: "text"; content: string }
  | { type: "math"; content: string; display: boolean }
  | { type: "image"; url: string; alt: string };

function parseMixedLatex(input: string): Segment[] {
  const segments: Segment[] = [];
  const regex = /(!\[[^\]]*\]\([^)]+\)|\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|\$[^$\n\r]*?\$|\\\([\s\S]*?\\\))/g;

  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(input)) !== null) {
    if (match.index > lastIndex) {
      const text = input.slice(lastIndex, match.index);
      if (text) segments.push({ type: "text", content: text });
    }

    const raw = match[0];

    if (raw.startsWith("![")) {
      const altMatch = raw.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
      if (altMatch) {
        segments.push({ type: "image", alt: altMatch[1], url: altMatch[2] });
      } else {
        segments.push({ type: "text", content: raw });
      }
    } else if (raw.startsWith("$$") && raw.endsWith("$$")) {
      segments.push({ type: "math", content: raw.slice(2, -2), display: true });
    } else if (raw.startsWith("\\[") && raw.endsWith("\\]")) {
      segments.push({ type: "math", content: raw.slice(2, -2), display: true });
    } else if (raw.startsWith("$") && raw.endsWith("$")) {
      segments.push({ type: "math", content: raw.slice(1, -1), display: false });
    } else if (raw.startsWith("\\(") && raw.endsWith("\\)")) {
      segments.push({ type: "math", content: raw.slice(2, -2), display: false });
    }

    lastIndex = match.index + raw.length;
  }

  if (lastIndex < input.length) {
    segments.push({ type: "text", content: input.slice(lastIndex) });
  }

  if (segments.length === 0 && input.trim()) {
    segments.push({ type: "text", content: input });
  }

  return segments;
}

export function KatexRenderer({ latex, className }: Props) {
  const segments = useMemo(() => parseMixedLatex(latex), [latex]);
  if (segments.length === 0) return null;

  return (
    <span className={className}>
      {segments.map((seg, i) => {
        if (seg.type === "text") {
          return <span key={i}>{seg.content}</span>;
        }
        if (seg.type === "image") {
          return (
            <img
              key={i}
              src={seg.url}
              alt={seg.alt || ""}
              className="question-image my-2 max-w-full rounded-md"
              loading="lazy"
            />
          );
        }
        return <MathSpan key={i} latex={seg.content} display={seg.display} />;
      })}
    </span>
  );
}

function MathSpan({ latex, display }: { latex: string; display: boolean }) {
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (ref.current) {
      try {
        katex.render(latex, ref.current, {
          displayMode: display,
          throwOnError: false,
          trust: true,
        });
      } catch {
        ref.current.textContent = latex;
      }
    }
  }, [latex, display]);

  return <span ref={ref} />;
}
