﻿"use client";

import { Button } from "@/components/ui/button";

const GROUPS = [
  {
    label: "常用",
    symbols: [
      { label: "分式", insert: "\\frac{}{}" },
      { label: "根号", insert: "\\sqrt{}" },
      { label: "n次根", insert: "\\sqrt[n]{}" },
      { label: "上下标", insert: "^{}_{}" },
      { label: "行内公式", insert: "\\(\\)", wrap: true },
      { label: "块级公式", insert: "$$$$", wrap: true },
    ],
  },
  {
    label: "希腊字母",
    symbols: [
      { label: "α", insert: "\\alpha" },
      { label: "β", insert: "\\beta" },
      { label: "γ", insert: "\\gamma" },
      { label: "θ", insert: "\\theta" },
      { label: "π", insert: "\\pi" },
      { label: "△", insert: "\\triangle" },
      { label: "φ", insert: "\\varphi" },
      { label: "ω", insert: "\\omega" },
    ],
  },
  {
    label: "运算符",
    symbols: [
      { label: "±", insert: "\\pm" },
      { label: "×", insert: "\\times" },
      { label: "÷", insert: "\\div" },
      { label: "·", insert: "\\cdot" },
      { label: "≤", insert: "\\leq" },
      { label: "≥", insert: "\\geq" },
      { label: "≠", insert: "\\neq" },
      { label: "⇒", insert: "\\Rightarrow" },
      { label: "⇔", insert: "\\Leftrightarrow" },
      { label: "∈", insert: "\\in" },
      { label: "⊆", insert: "\\subseteq" },
      { label: "∩", insert: "\\cap" },
      { label: "∪", insert: "\\cup" },
      { label: "∀", insert: "\\forall" },
      { label: "∃", insert: "\\exists" },
      { label: "∞", insert: "\\infty" },
    ],
  },
  {
    label: "函数",
    symbols: [
      { label: "sin", insert: "\\sin" },
      { label: "cos", insert: "\\cos" },
      { label: "tan", insert: "\\tan" },
      { label: "log", insert: "\\log" },
      { label: "ln", insert: "\\ln" },
      { label: "lim", insert: "\\lim_{x \\to 0}" },
      { label: "sum", insert: "\\sum_{}^{}" },
      { label: "int", insert: "\\int_{}^{}" },
    ],
  },
  {
    label: "结构",
    symbols: [
      { label: "括号", insert: "\\left( \\right)" },
      { label: "绝对值", insert: "\\left| \\right|" },
      { label: "矩阵", insert: "\\begin{matrix} a & b \\\\ c & d \\end{matrix}" },
      { label: "方程组", insert: "\\begin{cases} \\\\ \\end{cases}" },
      { label: "向量", insert: "\\vec{}" },
      { label: "上划线", insert: "\\overline{}" },
      { label: "下划线", insert: "\\underline{}" },
      { label: "帽子", insert: "\\hat{}" },
      { label: "空格", insert: "\\ " },
      { label: "换行", insert: "\\n" },
    ],
  },
];

type Props = {
  /** 要插入符号的 textarea/input 的 id，或通过回调 */
  onInsert: (text: string, wrap?: boolean) => void;
};

export function MathToolbar({ onInsert }: Props) {
  return (
    <div className="border rounded-md p-2 bg-muted/20 space-y-2">
      {GROUPS.map((group) => (
        <div key={group.label} className="flex items-center gap-1 flex-wrap">
          <span className="text-xs text-muted-foreground font-medium w-14 shrink-0">{group.label}</span>
          {group.symbols.map((sym) => (
            <Button
              key={sym.label}
              type="button"
              variant="outline"
              size="sm"
              className="h-7 px-2 text-xs font-mono"
              onClick={() => onInsert(sym.insert, sym.wrap)}
              title={sym.insert}
            >
              {sym.label}
            </Button>
          ))}
        </div>
      ))}
    </div>
  );
}
