import { prisma } from "@/lib/prisma";
import { QuestionForm } from "@/components/admin/question-form";

export const dynamic = "force-dynamic";

export default async function NewQuestionPage() {
  const chapters = await prisma.chapter.findMany({
    orderBy: { order: "asc" },
    include: {
      sections: {
        orderBy: { order: "asc" },
        include: {
          knowledgePoints: { orderBy: { id: "asc" } },
        },
      },
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">添加题目</h1>
        <p className="text-sm text-muted-foreground mt-1">
          手动录入新题目，支持 LaTeX 数学公式。题干、选项、答案、解析均使用 LaTeX 语法。
        </p>
      </div>
      <QuestionForm chapters={JSON.parse(JSON.stringify(chapters))} />
    </div>
  );
}