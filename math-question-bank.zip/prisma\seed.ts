import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// 北师大版 2019 高中数学教材目录
const curriculum = [
  {
    name: "必修第一册",
    sections: [
      {
        name: "第一章 集合",
        kps: ["集合的概念与表示", "集合的基本关系", "集合的基本运算"],
      },
      {
        name: "第二章 常用逻辑用语",
        kps: ["必要条件与充分条件", "全称量词与存在量词", "全称量词命题与存在量词命题的否定"],
      },
      {
        name: "第三章 不等式",
        kps: ["不等式的性质", "基本不等式", "一元二次不等式及其解法"],
      },
      {
        name: "第四章 函数",
        kps: ["函数的概念", "函数的表示法", "函数的单调性", "函数的奇偶性", "幂函数"],
      },
      {
        name: "第五章 指数函数与对数函数",
        kps: ["指数幂的拓展", "指数函数的概念与性质", "对数及其运算", "对数函数的概念与性质", "指数函数与对数函数的应用"],
      },
      {
        name: "第六章 三角函数",
        kps: ["任意角与弧度制", "任意角的三角函数", "同角三角函数的基本关系", "诱导公式", "正弦函数与余弦函数的图象和性质", "正切函数的图象和性质", "三角恒等变换", "函数y=Asin(ωx+φ)", "三角函数的应用"],
      },
    ],
  },
  {
    name: "必修第二册",
    sections: [
      {
        name: "第一章 平面向量",
        kps: ["向量的概念", "向量的线性运算", "向量的数量积", "向量的坐标表示", "向量的应用"],
      },
      {
        name: "第二章 复数",
        kps: ["复数的概念", "复数的几何意义", "复数的四则运算", "复数的三角形式"],
      },
      {
        name: "第三章 立体几何初步",
        kps: ["空间几何体的结构", "空间几何体的表面积与体积", "平面的基本性质", "空间中的平行关系", "空间中的垂直关系", "空间角的计算"],
      },
      {
        name: "第四章 统计",
        kps: ["随机抽样", "用样本估计总体", "频率分布直方图", "百分位数"],
      },
      {
        name: "第五章 概率",
        kps: ["随机事件与概率", "古典概型", "事件的独立性", "频率与概率"],
      },
    ],
  },
  {
    name: "选择性必修第一册",
    sections: [
      {
        name: "第一章 空间向量与立体几何",
        kps: ["空间向量的概念与运算", "空间向量基本定理", "空间向量的坐标表示", "利用空间向量研究立体几何问题"],
      },
      {
        name: "第二章 直线和圆的方程",
        kps: ["直线的倾斜角与斜率", "直线的方程", "两条直线的位置关系", "点到直线的距离", "圆的方程", "直线与圆的位置关系", "圆与圆的位置关系"],
      },
      {
        name: "第三章 圆锥曲线的方程",
        kps: ["椭圆及其标准方程", "椭圆的几何性质", "双曲线及其标准方程", "双曲线的几何性质", "抛物线及其标准方程", "抛物线的几何性质", "直线与圆锥曲线的位置关系"],
      },
    ],
  },
  {
    name: "选择性必修第二册",
    sections: [
      {
        name: "第一章 数列",
        kps: ["数列的概念", "等差数列", "等差数列的前n项和", "等比数列", "等比数列的前n项和", "数列求和", "数学归纳法"],
      },
      {
        name: "第二章 导数及其应用",
        kps: ["变化率与导数", "导数的几何意义", "基本初等函数的导数公式", "导数的四则运算法则", "复合函数的导数", "导数与函数的单调性", "导数与函数的极值和最值", "导数在实际问题中的应用"],
      },
    ],
  },
  {
    name: "选择性必修第三册",
    sections: [
      {
        name: "第一章 计数原理",
        kps: ["分类加法计数原理与分步乘法计数原理", "排列", "组合", "二项式定理", "杨辉三角"],
      },
      {
        name: "第二章 随机变量及其分布",
        kps: ["条件概率与全概率公式", "离散型随机变量及其分布列", "离散型随机变量的均值与方差", "二项分布", "超几何分布", "正态分布"],
      },
      {
        name: "第三章 成对数据的统计分析",
        kps: ["成对数据的统计相关性", "一元线性回归模型", "列联表与独立性检验"],
      },
    ],
  },
];

// 示例题目（与北师版知识点匹配）
const sampleQuestions = [
  {
    type: "choice",
    difficulty: 2,
    source: "同步练习",
    stemLatex: "已知集合 $$A = \\{x \\mid -2 < x < 3\\}$$, $$B = \\{x \\mid x^2 - 5x + 6 \\leq 0\\}$$, 则 $$A \\cap B =$$",
    options: JSON.stringify([
      { label: "A", latex: "\\{x \\mid 2 \\leq x < 3\\}" },
      { label: "B", latex: "\\{x \\mid -2 < x \\leq 3\\}" },
      { label: "C", latex: "\\{x \\mid -2 < x \\leq 2\\}" },
      { label: "D", latex: "\\{x \\mid x \\leq 2 \\text{ 或 } x \\geq 3\\}" },
    ]),
    answer: "A",
    solution: "解不等式 $$x^2 - 5x + 6 \\leq 0$$，得 $$(x-2)(x-3) \\leq 0$$，∴ $$2 \\leq x \\leq 3$$。\\n故 $$B = [2, 3]$$，又 $$A = (-2, 3)$$，\\n∴ $$A \\cap B = [2, 3)$$，选 A。",
  },
  {
    type: "fill",
    difficulty: 3,
    source: "同步练习",
    stemLatex: "已知函数 $$f(x) = x^3 - 3x + 1$$，则 $$f(x)$$ 在区间 $$[-2, 2]$$ 上的最大值为__________。",
    answer: "3",
    solution: "$$f'(x) = 3x^2 - 3 = 3(x-1)(x+1)$$\\n令 $$f'(x) = 0$$ 得 $$x = \\pm 1$$。\\n$$f(-2) = -8+6+1 = -1$$，$$f(-1) = -1+3+1 = 3$$，\\n$$f(1) = 1-3+1 = -1$$，$$f(2) = 8-6+1 = 3$$。\\n比较得最大值为 $$3$$。",
  },
  {
    type: "short_answer",
    difficulty: 4,
    source: "高考真题",
    stemLatex: "在 $$\\triangle ABC$$ 中，角 $$A, B, C$$ 的对边分别为 $$a, b, c$$，已知 $$a = 3$$, $$b = 4$$, $$\\cos C = \\frac{1}{4}$$。\\n(1) 求 $$c$$ 的值；\\n(2) 求 $$\\sin A$$ 的值。",
    answer: "(1) c = √19  (2) sinA = 3√15/(4√19)",
    solution: "(1) 由余弦定理：$$c^2 = a^2 + b^2 - 2ab\\cos C = 9 + 16 - 2 \\times 3 \\times 4 \\times \\frac{1}{4} = 19$$，\\n∴ $$c = \\sqrt{19}$$。\\n\\n(2) 由余弦定理：$$\\cos A = \\frac{b^2 + c^2 - a^2}{2bc} = \\frac{16+19-9}{2 \\times 4 \\times \\sqrt{19}} = \\frac{13}{4\\sqrt{19}}$$，\\n$$\\sin A = \\sqrt{1 - \\cos^2 A} = \\sqrt{1 - \\frac{169}{304}} = \\frac{3\\sqrt{15}}{4\\sqrt{19}}$$。",
  },
  {
    type: "choice",
    difficulty: 1,
    source: "同步练习",
    stemLatex: "若 $$a > b > 0$$，则下列不等式一定成立的是",
    options: JSON.stringify([
      { label: "A", latex: "\\frac{1}{a} > \\frac{1}{b}" },
      { label: "B", latex: "a^2 < b^2" },
      { label: "C", latex: "ac^2 > bc^2" },
      { label: "D", latex: "a - c > b - c" },
    ]),
    answer: "D",
    solution: "由 $$a > b$$，不等式两边同时减去 $$c$$ 得 $$a-c > b-c$$，选 D。\\nA 错误：$$a > b > 0$$ 时 $$\\frac{1}{a} < \\frac{1}{b}$$；\\nB 错误：平方后 $$a^2 > b^2$$；\\nC 错误：当 $$c=0$$ 时 $$ac^2 = bc^2$$。",
  },
  {
    type: "fill",
    difficulty: 2,
    source: "同步练习",
    stemLatex: "已知 $$\\sin\\alpha = \\frac{3}{5}$$，且 $$\\alpha$$ 是第二象限角，则 $$\\cos\\alpha =$$__________。",
    answer: "-4/5",
    solution: "由 $$\\sin^2\\alpha + \\cos^2\\alpha = 1$$ 得 $$\\cos^2\\alpha = 1 - \\frac{9}{25} = \\frac{16}{25}$$。\\n∵ $$\\alpha$$ 在第二象限，$$\\cos\\alpha < 0$$，∴ $$\\cos\\alpha = -\\frac{4}{5}$$。",
  },
];

async function main() {
  console.log("清空旧数据...");
  await prisma.practiceRecord.deleteMany();
  await prisma.paperQuestion.deleteMany();
  await prisma.paper.deleteMany();
  await prisma.questionKnowledgePoint.deleteMany();
  await prisma.question.deleteMany();
  await prisma.knowledgePoint.deleteMany();
  await prisma.section.deleteMany();
  await prisma.chapter.deleteMany();
  await prisma.user.deleteMany();
  await prisma.class.deleteMany();

  console.log("写入北师版高中数学教材结构...");
  let chapterOrder = 0;
  for (const ch of curriculum) {
    chapterOrder += 10;
    const chapter = await prisma.chapter.create({
      data: { name: ch.name, order: chapterOrder },
    });

    let sectionOrder = 0;
    for (const sec of ch.sections) {
      sectionOrder += 10;
      const section = await prisma.section.create({
        data: { name: sec.name, order: sectionOrder, chapterId: chapter.id },
      });

      for (const kpName of sec.kps) {
        await prisma.knowledgePoint.create({
          data: { name: kpName, sectionId: section.id },
        });
      }
    }
  }

  // 获取知识点来关联题目
  const allKps = await prisma.knowledgePoint.findMany({
    include: { section: { include: { chapter: true } } },
  });

  const findKp = (name: string) => allKps.find((k) => k.name === name)!;
  const questionsWithKps = [
    { ...sampleQuestions[0], kp: "集合的基本运算" },
    { ...sampleQuestions[1], kp: "导数与函数的单调性" },
    { ...sampleQuestions[2], kp: "向量的应用" },
    { ...sampleQuestions[3], kp: "不等式的性质" },
    { ...sampleQuestions[4], kp: "同角三角函数的基本关系" },
  ];

  console.log("写入示例题目...");
  for (const item of questionsWithKps) {
    const kp = findKp(item.kp);
    if (!kp) {
      console.log(`  跳过: 找不到知识点 "${item.kp}"`);
      continue;
    }
    const q = await prisma.question.create({
      data: {
        type: item.type,
        difficulty: item.difficulty,
        source: item.source,
        stemLatex: item.stemLatex,
        options: item.options,
        answer: item.answer,
        solution: item.solution,
        chapterId: kp.section.chapterId,
      },
    });
    await prisma.questionKnowledgePoint.create({
      data: { questionId: q.id, knowledgePointId: kp.id },
    });
  }

  // 创建管理员
  await prisma.user.create({
    data: { name: "管理员", email: "admin@math.local", password: "admin123", role: "admin" },
  });

  const chapterCount = await prisma.chapter.count();
  const sectionCount = await prisma.section.count();
  const kpCount = await prisma.knowledgePoint.count();
  const questionCount = await prisma.question.count();

  console.log(
    `完成! ${chapterCount}册 ${sectionCount}节 ${kpCount}个知识点 ${questionCount}道题`
  );
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());