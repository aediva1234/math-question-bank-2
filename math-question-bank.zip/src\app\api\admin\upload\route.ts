import { NextRequest, NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import { randomUUID } from "crypto";

const UPLOAD_DIR = join(process.cwd(), "public", "uploads");
const MAX_SIZE = 5 * 1024 * 1024;
const ALLOWED_TYPES = ["image/png", "image/jpeg", "image/webp", "image/gif", "image/svg+xml"];

const ERROR_MSGS: Record<string, string> = {
  noFile: "未选择文件",
  badType: "不支持的图片格式，仅支持 PNG/JPG/WebP/GIF/SVG",
  tooBig: "图片大小不能超过 5MB",
  fail: "上传失败",
};

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ error: ERROR_MSGS.noFile }, { status: 400 });
    }
    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json({ error: ERROR_MSGS.badType }, { status: 400 });
    }
    if (file.size > MAX_SIZE) {
      return NextResponse.json({ error: ERROR_MSGS.tooBig }, { status: 400 });
    }

    await mkdir(UPLOAD_DIR, { recursive: true });

    const ext = file.name.split(".").pop() || "png";
    const filename = randomUUID() + "." + ext;
    const buffer = Buffer.from(await file.arrayBuffer());
    const filepath = join(UPLOAD_DIR, filename);

    await writeFile(filepath, buffer);

    const url = "/uploads/" + filename;

    return NextResponse.json({ url, filename });
  } catch (e) {
    console.error("Upload error:", e);
    return NextResponse.json({ error: ERROR_MSGS.fail }, { status: 500 });
  }
}