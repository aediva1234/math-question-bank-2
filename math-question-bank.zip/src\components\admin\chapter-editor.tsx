"use client";

import { useState, useOptimistic, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Pencil, Trash2, Plus, ChevronDown, ChevronRight, GripVertical } from "lucide-react";

type Chapter = {
  id: number;
  name: string;
  order: number;
  sections: Section[];
};

type Section = {
  id: number;
  name: string;
  order: number;
  chapterId: number;
  knowledgePoints: KnowledgePoint[];
};

type KnowledgePoint = {
  id: number;
  name: string;
  sectionId: number;
};

type Props = {
  chapters: Chapter[];
};

async function apiCall(url: string, method: string, body?: unknown) {
  const res = await fetch(url, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export function ChapterEditor({ chapters: initialChapters }: Props) {
  const [chapters, setChapters] = useState(initialChapters);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());
  const [editing, setEditing] = useState<{
    type: "chapter" | "section" | "kp";
    id: number;
    name: string;
  } | null>(null);
  // New item states
  const [newChapterName, setNewChapterName] = useState("");
  const [addingSectionFor, setAddingSectionFor] = useState<number | null>(null);
  const [newSectionName, setNewSectionName] = useState("");
  const [addingKpFor, setAddingKpFor] = useState<number | null>(null);
  const [newKpName, setNewKpName] = useState("");
  const [isPending, startTransition] = useTransition();

  function toggleExpand(id: number) {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function refresh() {
    const res = await fetch("/api/admin/chapters");
    const data = await res.json();
    setChapters(data);
  }

  // --- Chapter CRUD ---
  async function addChapter() {
    if (!newChapterName.trim()) return;
    await apiCall("/api/admin/chapters", "POST", { name: newChapterName.trim() });
    setNewChapterName("");
    await refresh();
  }

  async function updateChapter(id: number, name: string) {
    await apiCall(`/api/admin/chapters?id=${id}`, "PATCH", { name });
    setEditing(null);
    await refresh();
  }

  async function deleteChapter(id: number) {
    if (!confirm("确定删除这一册及其下所有章节和知识点？")) return;
    await apiCall(`/api/admin/chapters?id=${id}`, "DELETE");
    await refresh();
  }

  // --- Section CRUD ---
  async function addSection(chapterId: number) {
    if (!newSectionName.trim()) return;
    await apiCall("/api/admin/chapters", "POST", {
      type: "section",
      chapterId,
      name: newSectionName.trim(),
    });
    setNewSectionName("");
    setAddingSectionFor(null);
    await refresh();
  }

  async function updateSection(id: number, name: string) {
    await apiCall(`/api/admin/chapters?id=${id}`, "PATCH", { type: "section", name });
    setEditing(null);
    await refresh();
  }

  async function deleteSection(id: number) {
    if (!confirm("确定删除这一节及其下所有知识点？")) return;
    await apiCall(`/api/admin/chapters?id=${id}`, "DELETE", { type: "section" });
    await refresh();
  }

  // --- KnowledgePoint CRUD ---
  async function addKp(sectionId: number) {
    if (!newKpName.trim()) return;
    await apiCall("/api/admin/chapters", "POST", {
      type: "kp",
      sectionId,
      name: newKpName.trim(),
    });
    setNewKpName("");
    setAddingKpFor(null);
    await refresh();
  }

  async function updateKp(id: number, name: string) {
    await apiCall(`/api/admin/chapters?id=${id}`, "PATCH", { type: "kp", name });
    setEditing(null);
    await refresh();
  }

  async function deleteKp(id: number) {
    if (!confirm("确定删除这个知识点？关联的题目不受影响。")) return;
    await apiCall(`/api/admin/chapters?id=${id}`, "DELETE", { type: "kp" });
    await refresh();
  }

  function renderEditableRow(
    type: "chapter" | "section" | "kp",
    id: number,
    name: string,
    extra: React.ReactNode
  ) {
    if (editing?.type === type && editing?.id === id) {
      return (
        <div className="flex items-center gap-2 flex-1">
          <Input
            value={editing.name}
            onChange={(e) => setEditing({ ...editing, name: e.target.value })}
            className="h-8"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                if (type === "chapter") updateChapter(id, editing.name);
                else if (type === "section") updateSection(id, editing.name);
                else updateKp(id, editing.name);
              }
              if (e.key === "Escape") setEditing(null);
            }}
          />
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              if (type === "chapter") updateChapter(id, editing.name);
              else if (type === "section") updateSection(id, editing.name);
              else updateKp(id, editing.name);
            }}
          >
            保存
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setEditing(null)}>
            取消
          </Button>
        </div>
      );
    }

    return (
      <>
        <span className="flex-1">{name}</span>
        {extra}
      </>
    );
  }

  return (
    <div className="space-y-4">
      {/* Add Chapter */}
      <Card>
        <CardContent className="pt-4">
          <div className="flex items-center gap-2">
            <Input
              placeholder="新建一册（如：必修第一册）"
              value={newChapterName}
              onChange={(e) => setNewChapterName(e.target.value)}
              className="h-9"
              onKeyDown={(e) => e.key === "Enter" && addChapter()}
            />
            <Button size="sm" onClick={addChapter}>
              <Plus className="size-4" /> 添加
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Chapter Tree */}
      {chapters.map((chapter) => {
        const isExpanded = expanded.has(chapter.id);
        return (
          <Card key={chapter.id}>
            <CardHeader
              className="py-3 px-4 cursor-pointer hover:bg-muted/50"
              onClick={() => toggleExpand(chapter.id)}
            >
              <div className="flex items-center gap-2">
                {isExpanded ? (
                  <ChevronDown className="size-4 text-muted-foreground shrink-0" />
                ) : (
                  <ChevronRight className="size-4 text-muted-foreground shrink-0" />
                )}
                <CardTitle className="text-base">
                  {renderEditableRow("chapter", chapter.id, chapter.name, null)}
                </CardTitle>
                <div
                  className="flex items-center gap-1 ml-auto"
                  onClick={(e) => e.stopPropagation()}
                >
                  <Button
                    size="icon"
                    variant="ghost"
                    className="size-7"
                    onClick={() =>
                      setEditing({ type: "chapter", id: chapter.id, name: chapter.name })
                    }
                  >
                    <Pencil className="size-3.5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="size-7 text-destructive"
                    onClick={() => deleteChapter(chapter.id)}
                  >
                    <Trash2 className="size-3.5" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            {isExpanded && (
              <CardContent className="pb-3 pt-0 pl-8 space-y-2">
                {/* Sections */}
                {chapter.sections.map((section) => (
                  <div key={section.id} className="border-l-2 border-muted pl-4 py-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-muted-foreground w-6 shrink-0">
                        §
                      </span>
                      <div className="flex items-center gap-1 flex-1 min-w-0">
                        {renderEditableRow("section", section.id, section.name, null)}
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="size-6"
                          onClick={() =>
                            setEditing({ type: "section", id: section.id, name: section.name })
                          }
                        >
                          <Pencil className="size-3" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="size-6 text-destructive"
                          onClick={() => deleteSection(section.id)}
                        >
                          <Trash2 className="size-3" />
                        </Button>
                      </div>
                    </div>

                    {/* Knowledge Points */}
                    <div className="ml-8 mt-1 space-y-1">
                      {section.knowledgePoints.map((kp) => (
                        <div key={kp.id} className="flex items-center gap-2 text-sm py-0.5">
                          <span className="text-muted-foreground">·</span>
                          <div className="flex items-center gap-1 flex-1 min-w-0">
                            {renderEditableRow("kp", kp.id, kp.name, null)}
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <Button
                              size="icon"
                              variant="ghost"
                              className="size-5"
                              onClick={() =>
                                setEditing({ type: "kp", id: kp.id, name: kp.name })
                              }
                            >
                              <Pencil className="size-2.5" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="size-5 text-destructive"
                              onClick={() => deleteKp(kp.id)}
                            >
                              <Trash2 className="size-2.5" />
                            </Button>
                          </div>
                        </div>
                      ))}

                      {/* Add KP */}
                      {addingKpFor === section.id ? (
                        <div className="flex items-center gap-1 pl-4">
                          <Input
                            placeholder="新知识点名称"
                            value={newKpName}
                            onChange={(e) => setNewKpName(e.target.value)}
                            className="h-7 text-sm"
                            autoFocus
                            onKeyDown={(e) => {
                              if (e.key === "Enter") addKp(section.id);
                              if (e.key === "Escape") {
                                setAddingKpFor(null);
                                setNewKpName("");
                              }
                            }}
                          />
                          <Button size="sm" variant="ghost" onClick={() => addKp(section.id)}>
                            确定
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setAddingKpFor(null);
                              setNewKpName("");
                            }}
                          >
                            取消
                          </Button>
                        </div>
                      ) : (
                        <button
                          className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground pl-4 py-0.5"
                          onClick={() => setAddingKpFor(section.id)}
                        >
                          <Plus className="size-3" /> 添加知识点
                        </button>
                      )}
                    </div>
                  </div>
                ))}

                {/* Add Section */}
                {addingSectionFor === chapter.id ? (
                  <div className="flex items-center gap-2 pl-2">
                    <span className="text-sm text-muted-foreground">§</span>
                    <Input
                      placeholder="新节名称"
                      value={newSectionName}
                      onChange={(e) => setNewSectionName(e.target.value)}
                      className="h-8 text-sm"
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === "Enter") addSection(chapter.id);
                        if (e.key === "Escape") {
                          setAddingSectionFor(null);
                          setNewSectionName("");
                        }
                      }}
                    />
                    <Button size="sm" variant="ghost" onClick={() => addSection(chapter.id)}>
                      确定
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setAddingSectionFor(null);
                        setNewSectionName("");
                      }}
                    >
                      取消
                    </Button>
                  </div>
                ) : (
                  <button
                    className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground pl-2"
                    onClick={() => setAddingSectionFor(chapter.id)}
                  >
                    <Plus className="size-3.5" /> 添加章节
                  </button>
                )}
              </CardContent>
            )}
          </Card>
        );
      })}
    </div>
  );
}