"use client";

import { useState, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MathToolbar } from "@/components/admin/math-toolbar";
import { LivePreview } from "@/components/question/live-preview";
import { BulkInput } from "@/components/admin/bulk-input";
import { ImageUploadButton } from "@/components/admin/image-upload";
import type { ParsedQuestion } from "@/lib/question-parser";
import { Plus, Trash2, Upload, FileText } from "lucide-react";

type Chapter = {
  id: number;
  name: string;
  sections: {
    id: number;
    name: string;
    knowledgePoints: { id: number; name: string }[];
  }[];
};

const TYPE_OPTIONS = [
  { value: "choice", label: "选择题" },
  { value: "fill", label: "填空题" },
  { value: "short_answer", label: "解答题" },
  { value: "proof", label: "证明题" },
];

export function QuestionForm({ chapters }: { chapters: Chapter[] }) {
  const router = useRouter();
  const [type, setType] = useState("choice");
  const [difficulty, setDifficulty] = useState(3);
  const [year, setYear] = useState("");
  const [source, setSource] = useState("");
  const [stemLatex, setStemLatex] = useState("");
  const [options, setOptions] = useState([
    { label: "A", latex: "" },
    { label: "B", latex: "" },
    { label: "C", latex: "" },
    { label: "D", latex: "" },
  ]);
  const [answer, setAnswer] = useState("");
  const [solution, setSolution] = useState("");
  const [chapterId, setChapterId] = useState("");
  const [selectedKpIds, setSelectedKpIds] = useState<number[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const [jsonInput, setJsonInput] = useState("");
  const [mode, setMode] = useState<"single" | "batch" | "bulk">("single");
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);

  const stemRef = useRef<HTMLTextAreaElement>(null);
  const solutionRef = useRef<HTMLTextAreaElement>(null);
  const activeRef = useRef<HTMLTextAreaElement | null>(null);

  const availableKps = chapterId
    ? chapters.find((c) => c.id === parseInt(chapterId))?.sections.flatMap((s) => s.knowledgePoints) || []
    : [];

  const toggleKp = (kpId: number) => {
    setSelectedKpIds((prev) => (prev.includes(kpId) ? prev.filter((id) => id !== kpId) : [...prev, kpId]));
  };

  const updateOption = (index: number, latex: string) => {
    setOptions((prev) => prev.map((o, i) => (i === index ? { ...o, latex } : o)));
  };

  const addOption = () => {
    const label = String.fromCharCode(65 + options.length);
    setOptions((prev) => [...prev, { label, latex: "" }]);
  };

  const removeOption = (index: number) => {
    setOptions((prev) =>
      prev.filter((_, i) => i !== index).map((o, i) => ({ ...o, label: String.fromCharCode(65 + i) }))
    );
  };

  const handleInsert = useCallback(
    (text: string, wrap?: boolean) => {
      const el = activeRef.current;
      if (!el) return;
      const start = el.selectionStart, end = el.selectionEnd;
      const before = el.value.substring(0, start);
      const selected = el.value.substring(start, end);
      const after = el.value.substring(end);
      let inserted: string;
      if (wrap && selected) {
        const parts = text.split("$");
        inserted = parts[0] + selected + parts[1];
      } else if (wrap) {
        const parts = text.split("$");
        inserted = parts.join("|");
        const cursorPos = inserted.indexOf("|");
        inserted = inserted.replace("|", "");
        el.value = before + inserted + after;
        el.selectionStart = el.selectionEnd = start + cursorPos;
        el.focus();
        if (el === stemRef.current) setStemLatex(el.value);
        else if (el === solutionRef.current) setSolution(el.value);
        return;
      } else {
        inserted = text;
      }
      el.value = before + inserted + after;
      el.selectionStart = el.selectionEnd = start + inserted.length;
      el.focus();
      if (el === stemRef.current) setStemLatex(el.value);
      else if (el === solutionRef.current) setSolution(el.value);
    },
    []
  );

  function handleApplyBulk(parsed: ParsedQuestion) {
    setStemLatex(parsed.stemLatex);
    setAnswer(parsed.answer);
    setSolution(parsed.solution);
    if (parsed.options.length >= 2) {
      setType("choice");
      setOptions(parsed.options);
    } else {
      setType("fill");
    }
    setMode("single");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    if (!stemLatex.trim()) { setError("请输入题干"); setSubmitting(false); return; }
    if (!answer.trim()) { setError("请输入答案"); setSubmitting(false); return; }

    try {
      const res = await fetch("/api/admin/questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type, difficulty,
          year: year ? parseInt(year) : null,
          source: source || null,
          stemLatex,
          options: type === "choice" ? JSON.stringify(options.filter((o) => o.latex.trim())) : null,
          answer,
          solution: solution || null,
          chapterId: chapterId ? parseInt(chapterId) : null,
          knowledgePointIds: selectedKpIds,
          images: JSON.stringify(uploadedImages),
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      router.push("/admin/questions");
      router.refresh();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "保存失败");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleBatchSubmit(items: ParsedQuestion[]) {
    setSubmitting(true);
    setError("");
    let ok = 0;
    for (const item of items) {
      try {
        const res = await fetch("/api/admin/questions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            type: item.options.length >= 2 ? "choice" : "fill",
            difficulty: 3,
            stemLatex: item.stemLatex,
            options: item.options.length >= 2 ? JSON.stringify(item.options) : null,
            answer: item.answer,
            solution: item.solution || null,
            images: "[]",
          }),
        });
        if (res.ok) ok++;
      } catch { /* skip */ }
    }
    setError(`成功导入 ${ok} / ${items.length} 题`);
    setSubmitting(false);
    if (ok > 0) { router.refresh(); }
  }

  return (
    <div className="space-y-6">
      {/* Mode tabs */}
      <div className="flex items-center gap-2">
        {(["single", "batch", "bulk"] as const).map((m) => (
          <Button
            key={m}
            type="button"
            variant={mode === m ? "default" : "outline"}
            size="sm"
            onClick={() => setMode(m)}
          >
            {m === "single" ? "单题录入" : m === "batch" ? "批量录入" : "整体录入"}
          </Button>
        ))}
      </div>

      {/* JSON / bulk mode */}
      {mode !== "single" && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">
              {mode === "batch" ? (
                <span className="flex items-center gap-2"><FileText className="size-4" /> 批量录入 (JSON 数组)</span>
              ) : (
                <span className="flex items-center gap-2"><Upload className="size-4" /> 整体录入</span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {mode === "batch" ? (
              <div className="space-y-3">
                <textarea
                  className="w-full h-48 font-mono text-sm border rounded-md p-3 bg-muted/30 resize-y"
                  value={jsonInput}
                  onChange={(e) => setJsonInput(e.target.value)}
                  placeholder='[{"type":"choice","stemLatex":"...","options":[...],"answer":"...","solution":"..."}]'
                />
                <Button type="button" size="sm" onClick={async () => {
                  try { const items: ParsedQuestion[] = JSON.parse(jsonInput); await handleBatchSubmit(items); }
                  catch { setError("JSON 格式错误"); }
                }} disabled={submitting}>
                  {submitting ? "导入中..." : "导入题目"}
                </Button>
              </div>
            ) : (
              <BulkInput onApply={handleApplyBulk} />
            )}
          </CardContent>
        </Card>
      )}

      {mode === "single" && (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Meta */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">基本信息</CardTitle></CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <label className="text-sm font-medium mb-1 block">题型</label>
                <select value={type} onChange={(e) => setType(e.target.value)} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
                  {TYPE_OPTIONS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">难度</label>
                <select value={difficulty} onChange={(e) => setDifficulty(parseInt(e.target.value))} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
                  {[1, 2, 3, 4, 5].map((d) => <option key={d} value={d}>{"★".repeat(d)}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">年份 (可选)</label>
                <Input value={year} onChange={(e) => setYear(e.target.value)} placeholder="如 2024" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">来源 (可选)</label>
                <Input value={source} onChange={(e) => setSource(e.target.value)} placeholder="如 高考全国Ⅰ卷" />
              </div>
            </CardContent>
          </Card>

          {/* Stem + Live Preview */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">题干 (LaTeX)</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              <MathToolbar onInsert={handleInsert} />
              <ImageUploadButton onInsert={(url) => { if (stemRef.current) { activeRef.current = stemRef.current; handleInsert(url); } setUploadedImages(prev => [...prev, url]); }} />
              <div className="grid gap-3 lg:grid-cols-2">
                <textarea
                  ref={(el) => { stemRef.current = el; }}
                  onFocus={() => { activeRef.current = stemRef.current; }}
                  className="w-full h-44 font-mono text-sm border rounded-md p-3 bg-muted/30 resize-y"
                  placeholder={`已知抛物线\\(C_1: y^2 = 2p_1x\\) 经过点\\((4,8)\\)，则...`}
                  value={stemLatex}
                  onChange={(e) => setStemLatex(e.target.value)}
                />
                <div className="border rounded-md p-3 bg-background overflow-auto max-h-44">
                  <p className="text-xs text-muted-foreground mb-2 font-medium">📝 实时预览</p>
                  <LivePreview latex={stemLatex} className="text-sm leading-relaxed" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Options */}
          {type === "choice" && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">选项 (LaTeX)</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  {options.map((opt, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-sm w-6 pt-2">{opt.label}.</span>
                      <Input value={opt.latex} onChange={(e) => updateOption(i, e.target.value)} placeholder={`选项 ${opt.label} 的 LaTeX`} className="flex-1" />
                      {options.length > 2 && <Button type="button" variant="ghost" size="icon" className="shrink-0 text-destructive" onClick={() => removeOption(i)}><Trash2 className="size-4" /></Button>}
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <Button type="button" variant="outline" size="sm" onClick={addOption}><Plus className="size-3.5" /> 添加选项</Button>
                </div>
                <div className="border rounded-md p-3 bg-background">
                  <p className="text-xs text-muted-foreground mb-2 font-medium">📝 选项预览</p>
                  <div className="space-y-1 text-sm">
                    {options.filter(o => o.latex.trim()).map((opt, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <span className="font-medium">{opt.label}.</span>
                        <LivePreview latex={opt.latex} />
                      </div>
                    ))}
                    {options.filter(o => o.latex.trim()).length === 0 && (
                      <span className="text-muted-foreground text-xs">输入选项后将在此预览...</span>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Answer & Solution */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">答案 (LaTeX)</CardTitle></CardHeader>
              <CardContent>
                <Input value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder={type === "choice" ? "如 A" : "如 3"} />
                {answer.trim() && (
                  <div className="mt-2 border rounded-md p-2 bg-background text-sm">
                    <span className="text-xs text-muted-foreground">预览：</span> <LivePreview latex={answer} />
                  </div>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">解析 (可选)</CardTitle></CardHeader>
              <CardContent>
                <ImageUploadButton onInsert={(url) => { if (solutionRef.current) { activeRef.current = solutionRef.current; handleInsert(url); } setUploadedImages(prev => [...prev, url]); }} />
                <textarea ref={(el) => { solutionRef.current = el; }} onFocus={() => { activeRef.current = solutionRef.current; }} className="w-full h-24 font-mono text-sm border rounded-md p-3 bg-muted/30 resize-y" value={solution} onChange={(e) => setSolution(e.target.value)} placeholder="逐步解析，支持 LaTeX..." />
                {solution.trim() && (
                  <div className="mt-2 border rounded-md p-2 bg-background text-sm leading-relaxed overflow-auto max-h-32">
                    <span className="text-xs text-muted-foreground">预览：</span> <LivePreview latex={solution} />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Knowledge Points */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">关联知识点</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div>
                <label className="text-sm font-medium mb-1 block">所属册</label>
                <select value={chapterId} onChange={(e) => { setChapterId(e.target.value); setSelectedKpIds([]); }} className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
                  <option value="">-- 选择册 --</option>
                  {chapters.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              {chapterId && availableKps.length > 0 && (
                <div>
                  <label className="text-sm font-medium mb-2 block">知识点（多选，已选 {selectedKpIds.length} 个）</label>
                  <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto">
                    {availableKps.map((kp) => (
                      <button key={kp.id} type="button" onClick={() => toggleKp(kp.id)} className={`text-xs px-2.5 py-1 rounded-full border ${selectedKpIds.includes(kp.id) ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-muted border-border"}`}>{kp.name}</button>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex items-center gap-3">
            <Button type="submit" disabled={submitting} size="lg">{submitting ? "保存中..." : "保存题目"}</Button>
            {error && <span className="text-sm text-destructive">{error}</span>}
          </div>
        </form>
      )}
    </div>
  );
}
