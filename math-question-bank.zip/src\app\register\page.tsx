"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, BookOpen, UserPlus } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (password.length < 6) { setError("密码至少 6 位"); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || "注册失败"); return; }
      router.push("/questions");
      router.refresh();
    } catch { setError("网络错误，请重试"); }
    finally { setLoading(false); }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-primary/5 px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
            <BookOpen className="size-6 text-primary" />
          </div>
          <h1 className="text-xl font-bold">创建账号</h1>
          <p className="text-sm text-muted-foreground mt-1">加入高中数学题库</p>
        </div>

        <div className="bg-white rounded-xl border shadow-sm p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">昵称</label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="你的名字" required />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">邮箱</label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" required />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">密码</label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="至少 6 位" required />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="size-4 animate-spin mr-2" /> : <UserPlus className="size-4 mr-2" />}
              注册
            </Button>
          </form>
          <p className="text-sm text-muted-foreground text-center mt-4">
            已有账号？ <Link href="/login" className="text-primary font-medium hover:underline">登录</Link>
          </p>
        </div>
      </div>
    </div>
  );
}